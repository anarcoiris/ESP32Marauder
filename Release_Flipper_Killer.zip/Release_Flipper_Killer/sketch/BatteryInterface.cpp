#line 1 "C:\\Users\\soyko\\Documents\\esp32_marauder\\ESP32Marauder\\esp32_marauder\\BatteryInterface.cpp"

// #ifdef HAS_BATTERY

#include "BatteryInterface.h"
#include "lang_var.h"
BatteryInterface::BatteryInterface() {

}

void BatteryInterface::main(uint32_t currentTime) {
  if (currentTime != 0) {
    if (currentTime - initTime >= 3000) {
      //Serial.println("Checking Battery Level");
      this->initTime = millis();
      int8_t new_level = this->getBatteryLevel();
      //this->battery_level = this->getBatteryLevel();
      if (this->battery_level != new_level) {
        Serial.println(text00 + (String)new_level);
        this->battery_level = new_level;
        Serial.println("Battery Level: " + (String)this->battery_level);
      }
    }
  }
}

void BatteryInterface::RunSetup() {
  byte error;
  byte addr;

  #ifdef HAS_BATTERY

    #ifdef BATTERY_ADC_PIN
        analogReadResolution(12);
        pinMode(BATTERY_ADC_PIN, INPUT);
        this->has_adc_battery = true;
        // this->i2c_supported = true;
        Serial.println(F("Battery: ADC mode"));

    #elif defined(HAS_AXP2101) && defined(I2C_SDA)
        bool result = this->power.begin(Wire, AXP2101_SLAVE_ADDRESS, I2C_SDA, I2C_SCL);

        if (!result)
          return;

        Serial.println(F("Detected AXP2101"));

        this->i2c_supported = true;
        this->has_axp2101 = true;

    #elif defined(I2C_SDA)  // other i2c (shared)

        Wire.begin(I2C_SDA, I2C_SCL);

        #ifdef HAS_IP5306
          Wire.beginTransmission(IP5306_ADDR);
          error = Wire.endTransmission();

          if (error == 0) {
            Serial.println(F("Detected IP5306"));
            this->has_ip5306 = true;
            this->i2c_supported = true;
          }
        #endif

        #ifdef HAS_AXP192
            axp192_obj.begin();
        #endif


        #ifdef HAS_MAX1704X
          Wire.beginTransmission(MAX17048_ADDR);
          error = Wire.endTransmission();

          if (error == 0) {
            if (maxlipo.begin()) {
              Serial.println(F("Detected MAX17048"));
              this->has_max17048 = true;
              this->i2c_supported = true;
            }
          }
        #endif

  #endif //  other i2c

    this->initTime = millis();
  #endif // HAS_BATTERY
}

int8_t BatteryInterface::getBatteryLevel() {

  #ifdef HAS_BATTERY

    #ifdef BATTERY_ADC_PIN
      if (this->has_adc_battery) {
        int voltage_mv = analogReadMilliVolts(BATTERY_ADC_PIN) * 2; // voltage divider ratio 2:1
        if (voltage_mv <= 3300) return 0;
        if (voltage_mv >= 4150) return 100;
        return (int8_t)(((voltage_mv - 3300) * 100) / 850);
      }
    #endif

    #ifdef HAS_IP5306
      if (this->has_ip5306) {
        Wire.beginTransmission(IP5306_ADDR);
        Wire.write(0x78);
        if (Wire.endTransmission(false) == 0 &&
            Wire.requestFrom(IP5306_ADDR, 1)) {
          this->i2c_supported = true;
          switch (Wire.read() & 0xF0) {
            case 0xE0: return 25;
            case 0xC0: return 50;
            case 0x80: return 75;
            case 0x00: return 100;
            default: return 0;
          }
        }
        this->i2c_supported = false;
        return -1;
      }
    #endif


    #ifdef HAS_MAX1704X
      if (this->has_max17048) {
        float percent = this->maxlipo.cellPercent();

        // Sometimes we dumb
        if (percent >= 100)
          return 100;
        else if (percent <= 0)
          return 0;
        else
          return percent;
      }
    #endif

    #ifdef HAS_AXP2101
      if (this->has_axp2101) {
        return this->power.getBatteryPercent();
      }
    #endif

  #endif // HAS_BATTERY

  return -1;
}

// #endif // HAS_BATTERY
