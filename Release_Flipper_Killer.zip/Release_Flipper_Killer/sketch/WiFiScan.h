#line 1 "C:\\Users\\soyko\\Documents\\esp32_marauder\\ESP32Marauder\\esp32_marauder\\WiFiScan.h"
#pragma once

#ifndef WiFiScan_h
#define WiFiScan_h

#include "configs.h"
#include "utils.h"
#include "GpsTrackerStats.h"
#include "IBeacon.h"
#include "RemoteIdDecoder.h"
#include "WigleFormat.h"

#include <ArduinoJson.h>
#include <algorithm>
#include <vector>

#ifdef HAS_BT
  #include <NimBLEDevice.h> // 1.3.8, 2.3.2

  #ifdef HAS_NIMBLE_2
    using MarauderBLEAdvertisedDevice = const NimBLEAdvertisedDevice;
  #else
    using MarauderBLEAdvertisedDevice = NimBLEAdvertisedDevice;
  #endif
#endif

/*#ifdef HAS_IDF_3
  extern "C" {
    #include "esp_netif.h"
    #include "esp_netif_net_stack.h"
  }
#endif*/

//#include <WiFi.h>
#include <ESP32Ping.h>
#include "EvilPortal.h"
#include <math.h>
#include "esp_wifi.h"
#include "esp_wifi_types.h"
#include <esp_timer.h>
#include "mbedtls/entropy.h"
#include "mbedtls/bignum.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/ecp.h"
#include <lwip/etharp.h>
#include <lwip/ip_addr.h>
#include <lwip/netif.h>
#include <lwip/tcpip.h>
#ifdef HAS_IDF_3
  #include "esp_netif.h"
  #include "esp_netif_net_stack.h"
  #include "esp_system.h"
  #include "esp_mac.h"
#endif
#if defined(HAS_BT) && !defined(HAS_NIMBLE_2)
  #include "esp_bt.h"
#endif
#ifdef HAS_SCREEN
  #include "Display.h"
#endif
#ifdef HAS_SD
  #include "SDInterface.h"
#endif
#include "Buffer.h"
#include "MemoryGuard.h"
#ifdef HAS_BATTERY
  #include "BatteryInterface.h"
#endif
#ifdef HAS_GPS
  #include "GpsInterface.h"
#endif
#include "settings.h"
#include "GeofenceMath.h"
#include "Assets.h"
#ifdef HAS_FLIPPER_LED
  #include "flipperLED.h"
#elif defined(XIAO_ESP32_S3) || defined(XIAO_ESP32_C5)
  #include "xiaoLED.h"
#elif defined(MARAUDER_M5STICKC)
  #include "stickcLED.h"
#elif defined(HAS_NEOPIXEL_LED) || defined(HAS_T_DONGLE_LED)
  #include "LedInterface.h"
#endif

#ifdef HAS_DIRECT_UPLOAD
  #include <WiFiClientSecure.h>
#endif

#define bad_list_length 3

#define OTA_UPDATE 100
#define SHOW_INFO 101
#define ESP_UPDATE 102
#define WIFI_SCAN_OFF 0
#define WIFI_SCAN_PROBE 1
#define WIFI_SCAN_AP 2
#define WIFI_SCAN_PWN 3
#define WIFI_SCAN_EAPOL 4
#define WIFI_SCAN_DEAUTH 5
#define WIFI_SCAN_ALL 6
#define WIFI_PACKET_MONITOR 7
#define WIFI_ATTACK_BEACON_SPAM 8
#define WIFI_ATTACK_RICK_ROLL 9
#define BT_SCAN_ALL 10
#define BT_SCAN_SKIMMERS 11
#define WIFI_SCAN_ESPRESSIF 12
#define LV_JOIN_WIFI 13
#define LV_ADD_SSID 14
#define WIFI_ATTACK_BEACON_LIST 15
#define WIFI_SCAN_TARGET_AP 16
#define LV_SELECT_AP 17
#define WIFI_ATTACK_AUTH 18
#define WIFI_ATTACK_MIMIC 19
#define WIFI_ATTACK_DEAUTH 20
#define WIFI_ATTACK_AP_SPAM 21
#define WIFI_SCAN_TARGET_AP_FULL 22
#define WIFI_SCAN_ACTIVE_EAPOL 23
#define WIFI_ATTACK_DEAUTH_MANUAL 24
#define WIFI_SCAN_RAW_CAPTURE 25
#define WIFI_SCAN_STATION 26
#define WIFI_ATTACK_DEAUTH_TARGETED 27
#define WIFI_SCAN_ACTIVE_LIST_EAPOL 28
#define WIFI_SCAN_SIG_STREN 29
#define WIFI_SCAN_EVIL_PORTAL 30
#define WIFI_SCAN_GPS_DATA 31
#define WIFI_SCAN_WAR_DRIVE 32
#define WIFI_SCAN_STATION_WAR_DRIVE 33
#define BT_SCAN_WAR_DRIVE 34
#define BT_SCAN_WAR_DRIVE_CONT 35
#define BT_ATTACK_SOUR_APPLE 36
#define BT_ATTACK_SWIFTPAIR_SPAM 37
#define BT_ATTACK_SPAM_ALL 38
#define BT_ATTACK_SAMSUNG_SPAM 39
#define WIFI_SCAN_GPS_NMEA 40
#define BT_ATTACK_GOOGLE_SPAM 41
#define BT_ATTACK_FLIPPER_SPAM 42
#define BT_SCAN_AIRTAG 43
#define BT_SPOOF_AIRTAG 44
#define BT_SCAN_FLIPPER 45
#define WIFI_SCAN_CHAN_ANALYZER 46
#define BT_SCAN_ANALYZER 47
#define WIFI_SCAN_PACKET_RATE 48
#define WIFI_SCAN_AP_STA 49
#define WIFI_SCAN_PINESCAN 50
#define WIFI_SCAN_MULTISSID 51
#define WIFI_CONNECTED 52
#define WIFI_PING_SCAN 53
#define WIFI_PORT_SCAN_ALL 54
#define GPS_TRACKER 55
#define WIFI_ATTACK_BAD_MSG 56
#define WIFI_ATTACK_BAD_MSG_TARGETED 57
#define WIFI_SCAN_TELNET 58
#define WIFI_SCAN_SSH 59
#define WIFI_ARP_SCAN 60
#define WIFI_ATTACK_SLEEP 61
#define WIFI_ATTACK_SLEEP_TARGETED 62
#define GPS_POI 63
#define WIFI_SCAN_DNS 64
#define WIFI_SCAN_HTTP 65
#define WIFI_SCAN_HTTPS 66
#define WIFI_SCAN_SMTP 67
#define WIFI_SCAN_RDP 68
#define WIFI_HOSTSPOT 69 // Nice
#define BT_SCAN_AIRTAG_MON 70
#define WIFI_SCAN_CHAN_ACT 71
#define BT_SCAN_FLOCK 72
#define BT_SCAN_SIMPLE 73
#define BT_SCAN_SIMPLE_TWO 74
#define BT_SCAN_FLOCK_WARDRIVE 75
#define WIFI_SCAN_DETECT_FOLLOW 76
#define WIFI_SCAN_SAE_COMMIT 77
#define WIFI_ATTACK_SAE_COMMIT 78
#define WIFI_ATTACK_CSA 79
#define WIFI_ATTACK_QUIET 80
#define BT_SCAN_RAYBAN 81
#define BT_ATTACK_APPLE_JUICE 82
#define WIFI_SCAN_DISPLAY_AP_INFO 83
#define BT_SCAN_FOX_HUNT 84
#define BT_SCAN_IBEACON 85
#define BT_FINDMY_SOUND 85
#define BT_ATTACK_FINDMY_LIVE 86
#define REMOTE_ID_SCAN_ALL 87
#define REMOTE_ID_SCAN_TARGET 88
#define WIFI_SCAN_CSI_MOTION 89

#define WIFI_ATTACK_FUNNY_BEACON 99 

#define BASE_MULTIPLIER 4

#define ANALYZER_NAME_REFRESH 100 // Number of events to refresh the name

// PineScan and Multi SSID
#define MULTISSID_THRESHOLD 3 // Threshold For Multi SSID
#define MAX_MULTISSID_ENTRIES 100 // Max number of confirmed MultiSSIDs to store
#define MAX_AP_ENTRIES 100 // Max number of APs to track for analysis
#define MAX_DISPLAY_ENTRIES 1 // Max Unique MACs to display
#define MAX_PINESCAN_ENTRIES 100 // PineScan Max Entries

#define MAX_CHANNEL     14

#define MAX_PORT 65535

#define WIFI_SECURITY_OPEN   0
#define WIFI_SECURITY_WEP    1
#define WIFI_SECURITY_WPA    2
#define WIFI_SECURITY_WPA2   3
#define WIFI_SECURITY_WPA3   4
#define WIFI_SECURITY_WPA_WPA2_MIXED 5
#define WIFI_SECURITY_WPA2_ENTERPRISE 6
#define WIFI_SECURITY_WPA3_ENTERPRISE 7
#define WIFI_SECURITY_WAPI 8
#define WIFI_SECURITY_UNKNOWN 255

#define WPS_CONFIG_USBA              0x0001
#define WPS_CONFIG_ETHERNET          0x0002
#define WPS_CONFIG_LABEL             0x0004
#define WPS_CONFIG_DISPLAY           0x0008
#define WPS_CONFIG_EXT_NFC_TOKEN     0x0010
#define WPS_CONFIG_INT_NFC_TOKEN     0x0020
#define WPS_CONFIG_NFC_INTERFACE     0x0040
#define WPS_CONFIG_PUSH_BUTTON       0x0080
#define WPS_CONFIG_KEYPAD            0x0100
#define WPS_CONFIG_VIRT_PUSH_BUTTON  0x1000
#define WPS_CONFIG_PHY_PUSH_BUTTON   0x2000
#define WPS_CONFIG_VIRT_DISPLAY      0x4000
#define WPS_CONFIG_PHY_DISPLAY       0x8000

#define CLEAR_APS   0
#define CLEAR_IPS   1
#define CLEAR_AT    2
#define CLEAR_FLIP  3
#define CLEAR_STA   4
#define CLEAR_PINE  5
#define CLEAR_MULTI 6
#define CLEAR_SSID  7
#define CLEAR_BLE   8

#define WIGLE_UPLOAD 0
#define WDG_UPLOAD   1
#define BOTH_UPLOAD  2

extern EvilPortal evil_portal_obj;

#ifdef HAS_SCREEN
  extern Display display_obj;
#endif
#ifdef HAS_SD
  extern SDInterface sd_obj;
#endif
#ifdef HAS_GPS
  extern GpsInterface gps_obj;
#endif
extern Buffer buffer_obj;
#ifdef HAS_BATTERY
  extern BatteryInterface battery_obj;
#endif
extern Settings settings_obj;
#ifdef HAS_FLIPPER_LED
  extern flipperLED flipper_led;
#elif defined(XIAO_ESP32_S3) || defined(XIAO_ESP32_C5)
  extern xiaoLED xiao_led;
#elif defined(MARAUDER_M5STICKC)
  extern stickcLED stickc_led;
#elif defined(HAS_NEOPIXEL_LED) || defined(HAS_T_DONGLE_LED)
  extern LedInterface led_obj;
#endif

esp_err_t esp_wifi_80211_tx(wifi_interface_t ifx, const void *buffer, int len, bool en_sys_seq);

#define EMPTY_ENTRY 0
#define VALID_ENTRY 1
#define TOMBSTONE_ENTRY 2

#ifdef HAS_BT

#define IS_AIRTAG 0
#define IS_FMNA   1
#define IS_DULT   2
static constexpr uint8_t AIRTAG_BEEP_COMMAND = 0xAF;

static const NimBLEUUID AIRTAG_SERVICE_UUID(
    "7dfc9000-7d1c-4951-86aa-8d9728f8d66c"
);

static const NimBLEUUID AIRTAG_CHARACTERISTIC_UUID(
    "7dfc9001-7d1c-4951-86aa-8d9728f8d66c"
);

static const NimBLEUUID FMNA_SERVICE_UUID(
    "0000fd44-0000-1000-8000-00805f9b34fb"
);

static const NimBLEUUID FMNA_SOUND_CHARACTERISTIC_UUID(
    "4f860003-943b-49ef-bed4-2f730304427a"
);

static const NimBLEUUID DULT_SERVICE_UUID(
    "15190001-12f4-c226-88ed-2ac5579f2a85"
);

static const NimBLEUUID DULT_SOUND_CHARACTERISTIC_UUID(
    "8e0c0001-1d68-fb92-bf61-48377421680e"
);

static const uint8_t FMNA_START_SOUND_COMMAND[] = {
    0x01, 0x00, 0x03
};

static const uint8_t FMNA_STOP_SOUND_COMMAND[] = {
    0x01, 0x01, 0x03
};

static const uint8_t DULT_START_SOUND_COMMAND[] = {
    0x00, 0x03
};

static const uint8_t DULT_STOP_SOUND_COMMAND[] = {
    0x01, 0x03
};

static NimBLEAddress pendingAddress(
    "00:00:00:00:00:00",
    BLE_ADDR_PUBLIC
);

bool connectionPending = false;
bool operationInProgress = false;
#endif

#pragma pack(push, 1)
struct MacEntry {
  uint8_t  mac[6];
  uint32_t last_seen_ms;
  uint16_t frame_count;
  int32_t  first_lat_e6;
  int32_t  first_lon_e6;
  int32_t  last_lat_e6;
  int32_t  last_lon_e6;
  bool following;
  int32_t dloc;
  int8_t rssi;
  bool bt;
};
#pragma pack(pop)

struct AirTag {
    String mac;                  // MAC address of the AirTag
    std::vector<uint8_t> payload; // Payload data
    uint16_t payloadSize;
    bool selected;
    int8_t rssi;
    uint32_t last_seen;
    bool is_airtag   = false;
    bool is_fmna     = false;
    bool is_dult     = false;
    bool connectable = true;
    #ifdef HAS_BT
    NimBLEAddress device_address;
    #endif
};

struct Flipper {
  String mac;
  String name;
  int8_t rssi = -128;
  uint32_t last_seen = 0;
};

struct BleDevice {
  uint8_t  mac[6];
  String   name;
  String   device_type;
  bool     selected = false;
  int      rssi     = -128;
  uint32_t last_seen_ms = 0;
  bool     is_ibeacon = false;
  marauder::IBeaconPayload ibeacon;
};

#ifdef HAS_PSRAM
  extern struct mac_addr* mac_history;
#endif

enum class MacSortMode : uint8_t {
  MOST_RECENT,
  MOST_FRAMES,
  HIGH_RSSI
};

class WiFiScan
{
  private:
#ifdef HAS_PSRAM
    static constexpr size_t REMOTE_ID_CAPACITY = 24;
#else
    static constexpr size_t REMOTE_ID_CAPACITY = 12;
#endif
    RemoteIdRecord remote_id_records[REMOTE_ID_CAPACITY];
    // GPX logging and display rendering are serialized on the main loop, so
    // they can safely reuse one stable snapshot workspace.
    RemoteIdRecord remote_id_snapshots[REMOTE_ID_CAPACITY];
    RemoteIdStore remote_id_store{remote_id_records, REMOTE_ID_CAPACITY};
    RemoteIdDecoder remote_id_decoder;
    mutable portMUX_TYPE remote_id_mux = portMUX_INITIALIZER_UNLOCKED;
    char remote_id_target_uas[21] = {};
    uint8_t remote_id_target_mac[6] = {};
    bool remote_id_target_has_uas = false;
    bool remote_id_target_selected = false;
    uint32_t remote_id_last_render_ms = 0;
    uint8_t remote_id_schedule_step = 0;
    uint8_t remote_id_beacon_channel_index = 0;
    #ifdef HAS_SD
      struct RemoteIdGpxTrack {
        char uasId[21] = {};
        uint8_t mac[6] = {};
        char name[22] = {};
        uint16_t pointCount = 0;
        bool used = false;
      };
      String remote_id_gpx_file_name;
      uint16_t remote_id_gpx_session_index = 0;
      RemoteIdGpxTrack remote_id_gpx_tracks[REMOTE_ID_CAPACITY];
      bool remote_id_gpx_active = false;
      void startRemoteIdGpx();
      void logRemoteIdGpxPositions(uint32_t nowMs);
      void finishRemoteIdGpx();
    #endif
    static constexpr uint32_t REMOTE_ID_STALE_MS = 30000;
    static constexpr uint32_t REMOTE_ID_EXPIRE_MS = 120000;
    void RunRemoteIdScan(uint8_t scan_mode, uint16_t color);
    void setupRemoteIdBle();
    void renderRemoteIdGlobal();
    void renderRemoteIdTarget();
    void logRemoteIdRecord(const RemoteIdRecord& record);
    void mergeRemoteIdRecord(RemoteIdRecord& destination,
                             const RemoteIdRecord& source);
    void hopRemoteIdChannel();
    size_t snapshotRemoteIds(RemoteIdRecord* records, size_t capacity) const;
    bool snapshotRemoteIdTarget(RemoteIdRecord& record) const;
    static void remoteIdWifiCallback(void* buf, wifi_promiscuous_pkt_type_t type);
    // Wardriver thanks to https://github.com/JosephHewitt
    int arp_count = 0;
    #ifndef HAS_PSRAM
      struct mac_addr mac_history[mac_history_len];
    #endif

    int current_act_len = 0;

    uint32_t chanActTime = 0;

    uint8_t ap_mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};
    uint8_t sta_mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};

    // Settings
    uint mac_history_cursor = 0;
    uint8_t channel_hop_delay = 1;

    #ifdef HAS_DIRECT_UPLOAD
      WiFiClientSecure *client = new WiFiClientSecure();
    #endif
  
    #if defined(HAS_SCREEN) && (defined(HAS_ILI9341) || \
        (defined(MARAUDER_MINI_V3) && !defined(DUAL_MINI_C5)) || \
        defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV))
      static const uint8_t PACKET_MONITOR_COLUMN_WIDTH = 4;
      #if defined(MARAUDER_MINI_V3) || defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV)
        static const uint8_t PACKET_MONITOR_GRAPH_LEFT = 24;
      #else
        static const uint8_t PACKET_MONITOR_GRAPH_LEFT = 32;
      #endif
      static const uint16_t PACKET_MONITOR_REFRESH_MS = 200;
      #if defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV)
        // Match the proven Mini v3 graph's 26-sample time window. The wider
        // Cardputer panel changes only the horizontal spacing, not the data
        // window, sampling cadence, scaling, or bar renderer.
        static const uint16_t PACKET_MONITOR_HISTORY_LEN = (128 - 24) / 4;
        static const uint8_t PACKET_MONITOR_COLUMN_STEP =
            (SCREEN_WIDTH - PACKET_MONITOR_GRAPH_LEFT) / PACKET_MONITOR_HISTORY_LEN;
      #else
        static const uint16_t PACKET_MONITOR_HISTORY_LEN =
            (SCREEN_WIDTH - PACKET_MONITOR_GRAPH_LEFT) / PACKET_MONITOR_COLUMN_WIDTH;
        static const uint8_t PACKET_MONITOR_COLUMN_STEP = PACKET_MONITOR_COLUMN_WIDTH;
      #endif
      uint16_t packet_monitor_beacons[PACKET_MONITOR_HISTORY_LEN] = {};
      uint16_t packet_monitor_deauths[PACKET_MONITOR_HISTORY_LEN] = {};
      uint16_t packet_monitor_probes[PACKET_MONITOR_HISTORY_LEN] = {};
      void resetPacketMonitorGraph();
      void samplePacketMonitorGraph();
      void drawPacketMonitorGraph(const uint16_t *values, int16_t top, int16_t bottom,
                                  uint16_t color, const char *label);
      void drawPacketMonitorGraphs();
      void drawPacketMonitorControls();
    #endif

    bool wsl_bypass_enabled = false;

    bool scan_complete = false;

    uint8_t wardrive_channel_index = 0;
    GeofenceConfig geofences[MAX_GEOFENCES];
    bool geofence_paused = false;
    uint32_t last_geofence_check = 0;
    String active_geofence_name = "";
    bool updateGeofenceState(bool force = false);
    void renderWardriveGeofenceState();
    void drawWardriveGeofenceBadge();

    //int num_beacon = 0; // GREEN
    //int num_probe = 0; // BLUE
    //int num_deauth = 0; // RED

    uint32_t initTime = 0;
    marauder::GpsTrackerStats gps_tracker_stats;
    uint32_t last_ui_update = 0;
    uint32_t last_sour_apple_update = 0;
    uint32_t last_ibeacon_ui_update = 0;
    bool run_setup = true;
    void initWiFi(uint8_t scan_mode);
    uint8_t bluetoothScanTime = 5;
    int packets_sent = 0;
    const wifi_promiscuous_filter_t filt = {.filter_mask=WIFI_PROMIS_FILTER_MASK_MGMT | WIFI_PROMIS_FILTER_MASK_DATA};
    #ifdef HAS_BT
      NimBLEScan* pBLEScan;
    #endif
    #ifdef HAS_NIMBLE_2
      NimBLEClient* nimbleClient;
    #endif

    const char* rick_roll[8] = {
      "01 Never gonna give you up",
      "02 Never gonna let you down",
      "03 Never gonna run around",
      "04 and desert you",
      "05 Never gonna make you cry",
      "06 Never gonna say goodbye",
      "07 Never gonna tell a lie",
      "08 and hurt you"
    };

    // H4W9 added Funny Beacon Spam
    const char* funny_beacon[12] = {
      "Abraham Linksys",
      "Benjamin FrankLAN",
      "Dora the Internet Explorer",
      "FBI Surveillance Van 4",
      "Get Off My LAN",
      "Loading...",
      "Martin Router King",
      "404 Wi-Fi Unavailable",
      "Test Wi-Fi Please Ignore",
      "This LAN is My LAN",
      "Titanic Syncing",
      "Winternet is Coming"
    };

    char* prefix = "G";

    typedef struct
    {
      int16_t fctl;
      int16_t duration;
      uint8_t da;
      uint8_t sa;
      uint8_t bssid;
      int16_t seqctl;
      unsigned char payload[];
    } __attribute__((packed)) WifiMgmtHdr;
    
    typedef struct {
      uint8_t payload[0];
      WifiMgmtHdr hdr;
    } wifi_ieee80211_packet_t;

		// Tracking structures for PineScan (similar to MultiSSID)
    struct PineScanTracker {
        uint8_t mac[6];
        bool suspicious_oui;
        bool tag_and_susp_cap;
        uint8_t channel;
        int8_t rssi;
        bool reported;
    };

    // For confirmed Pineapple devices
    struct ConfirmedPineScan {
        uint8_t mac[6];
        String detection_type;
        String essid;
        uint8_t channel;
        int8_t rssi;
        bool displayed;
    };
    LinkedList<PineScanTracker>* pinescan_trackers;
    LinkedList<ConfirmedPineScan>* confirmed_pinescan;
    bool pinescan_list_full_reported;
    
    // Security Conditions For Pineapple detection
    enum SecurityCondition {
        NONE = 0x00,
        SUSPICIOUS_WHEN_OPEN = 0x01,
        SUSPICIOUS_WHEN_PROTECTED = 0x02,
        SUSPICIOUS_ALWAYS = 0x04
    };

    // SuspiciousVendor struct
    struct SuspiciousVendor {
        const char* vendor_name;
        uint8_t security_flags;
        uint32_t ouis[20];                 // Array of OUIs (max 20 per vendor)
        uint8_t oui_count;                 // Number of OUIs for this vendor
    };

    // Declare the table for Pineapple
    static const SuspiciousVendor suspicious_vendors[];
    static const int NUM_SUSPICIOUS_VENDORS;

    // Track for AP list limit (Uninitialised, Done in RunSetup)
    bool ap_list_full_reported;

    // MULTI SSID STRUCTS

    struct MultiSSIDTracker {
        uint8_t mac[6];
        uint16_t ssid_hashes[MULTISSID_THRESHOLD];
        uint8_t unique_ssid_count;
        bool reported;
    };

    // New struct for confirmed MultiSSID devices
    struct ConfirmedMultiSSID {
        uint8_t mac[6];
        String essid;
        uint8_t channel;
        int8_t rssi;
        uint8_t ssid_count;
        bool displayed;
    };
    LinkedList<MultiSSIDTracker>* multissid_trackers;
    LinkedList<ConfirmedMultiSSID>* confirmed_multissid;
    bool multissid_list_full_reported;

    uint8_t sae_commit[32] = {
      0xb0, 0x00, 0x00, 0x00,                     // Type/Subtype, Duration
      0xBB, 0xBB, 0xBB, 0xBB, 0xBB, 0xBB,         // Destination
      0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA,         // Source
      0xBB, 0xBB, 0xBB, 0xBB, 0xBB, 0xBB,         // BSSID (Destination)
      0x00, 0x00,                                 // Frag num
      0x03, 0x00, 0x01, 0x00, 0x00, 0x00, 0x13, 0x00  // Auth alg (SAE), SAE sequence, group 19
    };

    // barebones packet
    uint8_t packet[128] = { 0x80, 0x00, 0x00, 0x00, //Frame Control, Duration
                    /*4*/   0xff, 0xff, 0xff, 0xff, 0xff, 0xff, //Destination address 
                    /*10*/  0x01, 0x02, 0x03, 0x04, 0x05, 0x06, //Source address - overwritten later
                    /*16*/  0x01, 0x02, 0x03, 0x04, 0x05, 0x06, //BSSID - overwritten to the same as the source address
                    /*22*/  0xc0, 0x6c, //Seq-ctl
                    /*24*/  0x83, 0x51, 0xf7, 0x8f, 0x0f, 0x00, 0x00, 0x00, //timestamp - the number of microseconds the AP has been active
                    /*32*/  0x64, 0x00, //Beacon interval
                    /*34*/  0x31, 0x00, //Capability info
                    /* SSID */
                    /*36*/  0x00
                    };

    uint8_t post_base[39] = {
      0x01, 0x08, 0x82, 0x84, 0x8b, 0x96, 0x24, 0x30, 0x48, 0x6c,
      0x03, 0x01, 0x04, 0x30, 0x18, 0x01, 0x00, 0x00, 0x0f, 0xac, 
      0x02, 0x02, 0x00, 0x00, 0x0f, 0xac, 0x04, 0x00, 0x0f, 0xac, 
      0x04, 0x01, 0x00, 0x00, 0x0f, 0xac, 0x02, 0x00, 0x00
    };

    uint8_t prob_req_packet[128] = {0x40, 0x00, 0x00, 0x00, 
                                  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, // Destination
                                  0x01, 0x02, 0x03, 0x04, 0x05, 0x06, // Source
                                  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, // Dest
                                  0x01, 0x00, // Sequence
                                  0x00, // SSID Parameter
                                  0x00, // SSID Length
                                  /* SSID */
                                  };

    uint8_t deauth_frame_default[26] = {
                              0xc0, 0x00, 0x3a, 0x01,
                              0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                              0xf0, 0xff, 0x02, 0x00
                          };

    uint8_t eapol_packet_bad_msg1[153] = {
                              0x08, 0x02,                         // Frame Control (EAPOL)
                              0x00, 0x00,                         // Duration
                              0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, // Destination (Broadcast)
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // Source (BSSID)
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // BSSID
                              0x30, 0x00,                         // Sequence Control
                              /* LLC / SNAP */
                              0xaa, 0xaa, 0x03, 0x00, 0x00, 0x00,
                              0x88, 0x8e,                          // Ethertype = EAPOL
                              /* -------- 802.1X Header -------- */
                              0x02,                               // Version 802.1X‑2004
                              0x03,                               // Type Key
                              0x00, 0x75,                          // Length 117 bytes
                              /* -------- EAPOL‑Key frame body (117 B) -------- */
                              0x02,                               // Desc Type 2 (AES/CCMP)
                              0x00, 0xCA,                          // Key Info (Install|Ack…)
                              0x00, 0x10,                          // Key Length = 16
                              /* Replay Counter (8) */
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01,
                              /* Nonce (32) */
                              0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                              0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                              0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
                              0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
                              /* Key IV (16) */
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                              /* Key RSC (8) */
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                              /* Key ID  (8) */ 
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                              /* Key MIC (16) */ 
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                              /* Key Data Len (2) */ 
                              0x00, 0x16,
                              /* Key Data (22 B) */
                              0xDD, 0x14,                // Vendor‑specific (PMKID IE)
                              0x00, 0x0F, 0xAC, 0x04,      // OUI + Type (PMKID)
                              /* PMKID (16 byte zero) */
                              0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 
                              0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x11
                          };

    uint8_t association_packet[200] = {
                              0x00, 0x10, // Frame Control (Association Request) PM=1
                              0x3a, 0x01, // Duration
                              0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, // Destination (Broadcast)
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // Source (Fake Source or BSSID)
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // BSSID
                              0x00, 0x00,                         // Sequence Control
                              0x31, 0x00,                         // Capability Information (PM=1)
                              0x0a, 0x00,                         // Listen Interval
                              0x00,                               // SSID tag
                              0x00,                               // SSID length      
                          };

    enum EBLEPayloadType
    {
      Microsoft,
      Apple,
      Samsung,
      Google,
      FlipperZero,
      Airtag,
      Apple2
    };

      #ifdef HAS_BT

      struct BLEData
      {
        NimBLEAdvertisementData AdvData;
        NimBLEAdvertisementData ScanData;
      };

      static void scanCompleteCB(BLEScanResults scanResults);
      NimBLEAdvertisementData GetUniversalAdvertisementData(EBLEPayloadType type);
    #endif

    #ifdef HAS_NIMBLE_2
      int connectAndProcessTracker(NimBLEAddress& address);
      bool backendFindMySound(NimBLEAddress& address, bool gui = false);
      bool sendAirtagSoundCommand(NimBLEClient* currentClient);
      bool sendFmnaSoundCommand(NimBLEClient* currentClient);
      bool sendDultSoundCommand(NimBLEClient* currentClient);
      bool enableTrackerResponses(NimBLERemoteCharacteristic* characteristic);
      void releaseNimbleClient();
      void createNimbleClient();
      void initializeFindMyScan();
    #endif

    bool wigleUpload(String filePath);
    bool wdgwarsUpload(String filePath);
    void writeSidecar(String filePath, String service);
    bool sidecarExists(String filePath, String service); 
    #ifdef HAS_SCREEN
      void drawUploadProgress(const char* service, uint8_t percent, bool waiting = false);
    #endif

    void runFoxHunt(uint32_t currentTime);
    bool throwThatShitInACircle();
    void displayTargetFilter();
    void displayTransmitRate();
    void prepareScanStage(uint16_t color_1, uint16_t color_2);
    void setLEDMode(int mode);
    void setWiFiMode(wifi_mode_t mode, wifi_promiscuous_cb_t cb);
    void writeNetworkInfo();
    void setupScanDisplayArea(uint16_t background, uint16_t color);
    void updateTrackerUI();
    void showNetworkInfo(bool show_display = true);
    void resetNetworkScanDisplay(const String& target_line, const String& status_line);
    void addNetworkScanDisplayResult(const String& result_line);
    void finishNetworkScanDisplay(const String& result_label);
    void setNetworkInfo();
    void fullARP();
    bool readARP(IPAddress targ_ip);
    bool singleARP(IPAddress ip_addr);
    void pingScan(uint8_t scan_mode = WIFI_PING_SCAN);
    void portScan(uint8_t scan_mode = WIFI_PORT_SCAN_ALL, uint16_t targ_port = 22);
    IPAddress advanceScanIP();
    bool isHostAlive(IPAddress ip);
    bool checkHostPort(IPAddress ip, uint16_t port, uint16_t timeout = 100);
    String extractManufacturer(const uint8_t* payload, size_t payload_len);
    int checkMatchAP(char addr[], bool update_ap = true);
    uint8_t getSecurityType(const uint8_t* beacon, uint16_t len);
    void addAnalyzerValue(int16_t value, int rssi_avg, int16_t target_array[], int array_size);
    bool mac_cmp(struct mac_addr addr1, struct mac_addr addr2);
    bool mac_cmp(uint8_t addr1[6], uint8_t addr2[6]);
    // POI tagging during wardrive
    File poiFile;
    bool poiFileOpen = false;
    String poiFileName = "";

    void openPoiFile();
    void closePoiFile();

    void executeWarDrive();
    void executeBLESpam(EBLEPayloadType type);
    void startWardriverWiFi();
    void saeAttackLoop(uint32_t currentTime);
    void processPwnagotchiBeacon(const uint8_t* frame, int length);

    void startWiFiAttacks(uint8_t scan_mode, uint16_t color, const char* title_string);

    void signalAnalyzerLoop(uint32_t tick);
    void channelActivityLoop(uint32_t tick);
    void packetRateLoop(uint32_t tick);
    void packetMonitorMain(uint32_t currentTime);
    void updateMidway();
    bool sendSAECommitFrame(uint8_t* targ_addr, uint8_t* src_addr) ;
    void sendProbeAttack(uint32_t currentTime);
    void sendBadMsgAttack(uint32_t currentTime, bool all = false);
    void sendAssocSleepAttack(uint32_t currentTime, bool all = false);
    void sendDeauthFrame(uint8_t bssid[6], int channel, uint8_t mac[6]);
    void sendEapolBagMsg1(uint8_t bssid[6], int channel, uint8_t mac[6], uint8_t sec = WIFI_SECURITY_WPA2);
    void sendAssociationSleep(const char* ESSID, uint8_t bssid[6], int channel, uint8_t mac[6]);
    void broadcastRandomSSID(uint32_t currentTime);
    void broadcastCustomBeacon(uint32_t current_time, ssid custom_ssid, bool for_camera = false);
    void broadcastCustomBeacon(uint32_t current_time, AccessPoint custom_ssid, int scan_mode);
    void broadcastSetSSID(uint32_t current_time, const char* ESSID, uint8_t chan = 0, bool legit = false);
    void executeFindMyLive(uint32_t current_time);
    void RunAPScan(uint8_t scan_mode, uint16_t color);
    void RunGPSNmea();
    void RunPwnScan(uint8_t scan_mode, uint16_t color);
    void RunPineScan(uint8_t scan_mode, uint16_t color);
    void RunMultiSSIDScan(uint8_t scan_mode, uint16_t color);
    void RunBeaconScan(uint8_t scan_mode, uint16_t color);
    void RunRawScan(uint8_t scan_mode, uint16_t color);
    void RunDeauthScan(uint8_t scan_mode, uint16_t color);
    void RunEapolScan(uint8_t scan_mode, uint16_t color);
    void RunProbeScan(uint8_t scan_mode, uint16_t color);
    void RunSAEScan(uint8_t scan_mode, uint16_t color);
    void RunPacketMonitor(uint8_t scan_mode, uint16_t color);
    void RunBluetoothScan(uint8_t scan_mode, uint16_t color);
    void RunSourApple(uint8_t scan_mode, uint16_t color);
    void RunFindMyLive(uint8_t scan_mode, uint16_t color);
    void RunSwiftpairSpam(uint8_t scan_mode, uint16_t color);
    void RunEvilPortal(uint8_t scan_mode, uint16_t color);
    void RunPingScan(uint8_t scan_mode, uint16_t color);
    void RunPortScanAll(uint8_t scan_mode, uint16_t color);
    bool checkMem(size_t requestedBytes = 0);
    void writeHeader(bool poi = false);
    void writeFooter(bool poi = false);
    void displayWardriveStats();
    void displayAPStats();


  public:
    struct FoxHuntTarget {
      uint8_t mac[6] = {};
      String name = "";
      int8_t rssi = -128;
      uint8_t channel = 1;
      bool bluetooth = false;
      bool active = false;
      uint32_t last_seen_ms = 0;
      String advertised_address = "";
    };

    FoxHuntTarget fox_hunt_target;

    volatile bool bt_cb_busy = false;
    volatile bool bt_pending_clear = false;

    bool send_deauth = false;

    bool processRemoteIdWifiFrame(const uint8_t* frame, size_t length,
                                  const uint8_t mac[6], int8_t rssi,
                                  uint8_t channel);
    bool processRemoteIdBlePayload(const uint8_t* payload, size_t length,
                                   const uint8_t mac[6], int8_t rssi,
                                   RemoteIdTransport transport =
                                       RemoteIdTransport::BleLegacy);
    size_t remoteIdCount() const;
    String remoteIdLabel(size_t index) const;
    bool selectRemoteIdTarget(size_t index);
    void clearRemoteIds();

    size_t retainedAccessPointCount() const;
    size_t retainedStationCount() const;
    size_t retainedBleDeviceCount() const;

    bool channel_hop = false;
    uint8_t connected_devices = 0;


    static MacEntry mac_entries[mac_history_len_half];
    static uint8_t mac_entry_state[mac_history_len_half];

    String header_line = "WigleWifi-1.6,appRelease=" + (String)MARAUDER_VERSION + ",model=ESP32 Marauder,release=" + (String)MARAUDER_VERSION + ",device=ESP32 Marauder,display=SPI TFT,board=ESP32 Marauder,brand=JustCallMeKoko\n" + WIGLE_CSV_COLUMNS + "\n";

    uint8_t dual_band_channels[DUAL_BAND_CHANNELS] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84, 88, 92, 96, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144, 149, 153, 157, 161, 165, 169, 173, 177};

    uint8_t oui_list[27][3] = {
    {0x58, 0x8E, 0x81},
    {0xCC, 0xCC, 0xCC},
    {0xEC, 0x1B, 0xBD},
    {0x90, 0x35, 0xEA},
    {0x04, 0x0D, 0x84},
    {0xF0, 0x82, 0xC0},
    {0x1C, 0x34, 0xF1},
    {0x38, 0x5B, 0x44},
    {0x94, 0x34, 0x69},
    {0xB4, 0xE3, 0xF9},
    {0x70, 0xC9, 0x4E},
    {0x3C, 0x91, 0x80},
    {0xD8, 0xF3, 0xBC},
    {0x80, 0x30, 0x49},
    {0x14, 0x5A, 0xFC},
    {0x74, 0x4C, 0xA1},
    {0x08, 0x3A, 0x88},
    {0x9C, 0x2F, 0x9D},
    {0x94, 0x08, 0x53},
    {0xE4, 0xAA, 0xEA},
    {0xF4, 0x6A, 0xDD},
    {0xF8, 0xA2, 0xD6},
    {0xE0, 0x0A, 0xF6},
    {0x00, 0xF4, 0x8D},
    {0xD0, 0x39, 0x57},
    {0xE8, 0xD0, 0xFC},
    {0xB4, 0x1E, 0x52}
    };

    uint8_t dual_band_channel_index = 0;

    // Shoutout https://github.com/NullPxl
    const uint16_t META_IDENTIFIERS[6] = {
      0xFD5F,  // Meta (0xFD5F)
      0xFEB7,  // Meta (0xFEB7)
      0xFEB8,  // Meta (0xFEB8)
      0x01AB,  // Meta (0x01AB)
      0x058E,  // Meta (0x058E)
      0x0D53,   // Luxottica (0x0D53)
    };

    const uint16_t BLOCKED_IDENTIFIERS[5] = {
      0xFD5A,  // Samsung
      0xFD69,   // Samsung
      0x004C, //apple
      0x0006, // microsoft
      0xFEF3, // phone
    };

    // Stuff for RAW stats
    uint32_t mgmt_frames = 0;
    uint32_t data_frames = 0;
    uint32_t beacon_frames = 0;
    uint32_t req_frames = 0;
    uint32_t resp_frames = 0;
    uint32_t deauth_frames = 0;
    uint32_t eapol_frames = 0;
    uint32_t complete_eapol = 0;
    uint32_t flock_devices = 0;
    int8_t min_rssi = 0;
    int8_t max_rssi = -128;

    int bt_frames = 0;

    bool force_pmkid = false;
    bool force_probe = false;
    bool save_pcap = false;
    bool ep_deauth = false;
    bool ble_scanning = false;

    char* flock_ssid[5] = {
      "flock",
      "penguin",
      "pigvision",
      "fs ext battery",
      "Flock"
    };

    #ifdef HAS_DUAL_BAND
      uint8_t channel_activity[DUAL_BAND_CHANNELS] = {};
    #else
      uint8_t channel_activity[MAX_CHANNEL] = {};
    #endif

    uint8_t activity_page = 1;

    String analyzer_name_string = "";
    
    uint8_t analyzer_frames_recvd = 0;

    bool analyzer_name_update = false;

    uint8_t set_channel = 1;

    uint8_t old_channel = 0;

    int16_t _analyzer_value = 0;

    bool orient_display = false;
    bool wifi_initialized = false;
    bool ble_initialized = false;
    bool wifi_connected = false;

    String free_ram = "";
    String old_free_ram = "";
    String connected_network = "";
    char pending_wifi_ssid[33] = {};
    char pending_wifi_password[64] = {};
    bool pending_wifi_credential = false;

    IPAddress ip_addr;
    IPAddress gateway;
    IPAddress subnet;

    IPAddress current_scan_ip;
    IPAddress last_scan_ip;

    uint16_t current_scan_port = 1;
    uint16_t network_scan_result_count = 0;

    String dst_mac = "ff:ff:ff:ff:ff:ff";
    byte src_mac[6] = {};

    #ifdef HAS_SCREEN
      #if !defined(MARAUDER_CARDPUTER) && !defined(MARAUDER_CARDPUTER_ADV)
        int16_t _analyzer_values[TFT_WIDTH];
        int16_t _temp_analyzer_values[TFT_WIDTH];
      #else
        int16_t _analyzer_values[SCREEN_WIDTH];
        int16_t _temp_analyzer_values[SCREEN_WIDTH];
      #endif
    #endif

    String current_mini_kb_ssid = "";

    const String alfa = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789-=[];',./`\\_+{}:\"<>?~|!@#$%^&*()";

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();

    #ifndef HAS_IDF_3
      wifi_init_config_t cfg2 = { \
          .event_handler = &esp_event_send_internal, \
          .osi_funcs = &g_wifi_osi_funcs, \
          .wpa_crypto_funcs = g_wifi_default_wpa_crypto_funcs, \
          .static_rx_buf_num = 6,\
          .dynamic_rx_buf_num = 6,\
          .tx_buf_type = 0,\
          .static_tx_buf_num = 1,\
          .dynamic_tx_buf_num = WIFI_DYNAMIC_TX_BUFFER_NUM,\
          .cache_tx_buf_num = 0,\
          .csi_enable = false,\
          .ampdu_rx_enable = false,\
          .ampdu_tx_enable = false,\
          .amsdu_tx_enable = false,\
          .nvs_enable = false,\
          .nano_enable = WIFI_NANO_FORMAT_ENABLED,\
          .rx_ba_win = 6,\
          .wifi_task_core_id = WIFI_TASK_CORE_ID,\
          .beacon_max_len = 752, \
          .mgmt_sbuf_num = 8, \
          .feature_caps = g_wifi_feature_caps, \
          .sta_disconnected_pm = WIFI_STA_DISCONNECTED_PM_ENABLED,  \
          .espnow_max_encrypt_num = 0, \
          .magic = WIFI_INIT_CONFIG_MAGIC\
      };
    #else
      wifi_country_t country = {
        .cc = "PH",
        .schan = 1,
        .nchan = 13,
        .policy = WIFI_COUNTRY_POLICY_AUTO,
      };

      wifi_init_config_t cfg2 = WIFI_INIT_CONFIG_DEFAULT();
    #endif

    wifi_config_t ap_config;

    bool uploadFile(String filePath, bool retry = false, uint8_t upload_type = WIGLE_UPLOAD);
    String checkEmptyProbe(String essid);
    bool checkFlockOUI(const uint8_t mac[6]);
    bool startWiFi(String ssid, String password, bool gui = true);
    bool isFlockCamera(const uint8_t* payload, size_t len, const String& name, String* serial_out);
    int seenBLEDevice(BleDevice ble_device);
    bool retainBLEDevice(const BleDevice& ble_device);
    bool shouldRenderIBeaconEvent(uint32_t current_time);
    uint16_t rssiToColor(int8_t rssi);
    bool isMetaIdentifier(uint16_t id);
    bool isBlockedIdentifier(uint16_t id);
    #ifdef HAS_BT
      String classifyBLEDevice(MarauderBLEAdvertisedDevice* advertised_device);
      void retainBLEFoxHuntSubtype(MarauderBLEAdvertisedDevice* advertised_device,
                                   const BleDevice& ble_device);
    #endif
    void setFoxHuntTarget(const uint8_t mac[6], const String& name, int8_t rssi, uint8_t channel, bool bluetooth, const String& advertised_address = "");
    bool updateFoxHuntRssi(const uint8_t mac[6], int8_t rssi, uint8_t channel = 0);
    bool updateBluetoothFoxHuntRssi(const uint8_t mac[6], const String& advertised_address, int8_t rssi);
    size_t getPineScanCount() const;
    String getPineScanLabel(size_t index) const;
    int8_t getPineScanRssi(size_t index) const;
    uint8_t getPineScanChannel(size_t index) const;
    bool selectPineScanFoxTarget(size_t index);
    size_t getMultiSSIDCount() const;
    String getMultiSSIDLabel(size_t index) const;
    int8_t getMultiSSIDRssi(size_t index) const;
    uint8_t getMultiSSIDChannel(size_t index) const;
    bool selectMultiSSIDFoxTarget(size_t index);
    uint32_t getCompleteEapol(int check_index = -1);
    void drawChannelLine();
    #ifdef HAS_SCREEN
      int8_t checkAnalyzerButtons(uint32_t currentTime);
    #endif
    bool seen_mac(unsigned char* mac, bool simple = true);
    int update_mac_entry(const uint8_t mac[6], int8_t rssi = 0, bool bt = false);
    inline void insert_mac_entry(uint32_t idx, const uint8_t mac[6], uint32_t now_ms, int8_t rssi = 0, bool bt = false);
    void evict_and_insert(const uint8_t mac[6], uint32_t now_ms, int8_t rssi, bool bt);
    uint8_t build_top10_for_ui(MacEntry* out_top10, MacSortMode mode);
    void save_mac(unsigned char* mac);
    #ifdef HAS_BT
      void copyNimbleMac(const BLEAddress &addr, unsigned char out[6]);
    #endif
    #ifdef HAS_NIMBLE_2
      bool executeFindMySound(bool gui = false);
    #endif
    bool filterActive();
    bool RunGPSInfo(bool tracker = false, bool display = true, bool poi = false);
    void logPoint(String lat, String lon, float alt, String datetime, bool poi = false);
    void setMac();
    void renderRawStats();
    void renderPacketRate();
    void displayAnalyzerString(String str);
    String security_int_to_string(int security_type);
    void RunSetup();
    int clearList(uint8_t list_type);
    bool addSSID(String essid);
    int generateSSIDs(int count = 20);
    bool shutdownWiFi();
    bool shutdownBLE();
    bool scanning();
    bool joinWiFi(String ssid, String password, bool gui = true, bool save_credential = true);
    bool joinSavedWiFi(bool gui = true);
    void reloadGeofences();
    bool isGeofencePaused() const { return geofence_paused; }
    bool hasPendingWifiCredential() const;
    bool savePendingWifiCredential(uint8_t replace_index);
    void discardPendingWifiCredential();
    void getMAC(bool get_sta, uint8_t* mac);
    void changeChannel(int chan = -1);
    void RunAPInfo(uint16_t index, bool do_display = true);
    void RunInfo();
    void RunSetMac(uint8_t * mac, bool ap = true);
    void RunGenerateRandomMac(bool ap = true);
    void RunGenerateSSIDs(int count = 20);
    void RunClearSSIDs();
    void RunClearAPs();
    void RunClearStations();
    void RunSaveSSIDList(bool save_as = true);
    void RunLoadSSIDList();
    void RunSaveAPList(bool save_as = true);
    void RunLoadAPList();
    void RunSaveATList(bool save_as = true);
    void RunLoadATList();
    void RunSetupGPSTracker(uint8_t scan_mode);
    void channelHop(bool filtered = false, bool ranged = false);
    uint8_t currentScanMode = 0;
    void main(uint32_t currentTime);
    void StartScan(uint8_t scan_mode, uint16_t color = 0);
    void StopScan(uint8_t scan_mode);
    void setBaseMacAddress(uint8_t macAddr[6]);

    uint16_t poiCount = 0;
    void tagPOI(const char* label = nullptr);

    bool save_serial = false;
    void startPcap(const char* file_name);
    void startLog(const char* file_name);
    void startGPX(const char* file_name);

    static WiFiEventId_t eventId;
    static String lastClientMAC;
    static String lastClientIP;

    static void onWiFiEvent(WiFiEvent_t event, WiFiEventInfo_t info);
    static bool initMbedtls();
    static int mbedtls_entropy_source(void *data, unsigned char *output, size_t len);
    static bool getSAEACT(const uint8_t *frame, size_t frame_len, uint16_t &group_out, size_t &act_len_out);
    static bool sae_group_sizes(uint16_t group, size_t &scalar_len, size_t &element_len);
    static bool mac_cmp(const uint8_t *a, const uint8_t *b);
    static inline uint16_t le16(const uint8_t *p);
    static void getMAC(char *addr, uint8_t* data, uint16_t offset);
    static void getMAC(uint8_t* mac, const uint8_t* data, uint16_t offset);
    static void beaconSnifferCallback(void* buf, wifi_promiscuous_pkt_type_t type);
    static void apSnifferCallbackFull(void* buf, wifi_promiscuous_pkt_type_t type);
    static void eapolSnifferCallback(void* buf, wifi_promiscuous_pkt_type_t type);
    static void wifiSnifferCallback(void* buf, wifi_promiscuous_pkt_type_t type);
    static void pineScanSnifferCallback(void* buf, wifi_promiscuous_pkt_type_t type); // Pineapple
    static int extractPineScanChannel(const uint8_t* payload, int len); // Pineapple
    static void multiSSIDSnifferCallback(void* buf, wifi_promiscuous_pkt_type_t type); // MultiSSID
    #ifdef HAS_NIMBLE_2
      static void trackerNotifyCallback(NimBLERemoteCharacteristic* characteristic, uint8_t* data, size_t length, bool isNotify);
    #endif
    static inline uint32_t hash_mac(const uint8_t mac[6]);
};
#endif
