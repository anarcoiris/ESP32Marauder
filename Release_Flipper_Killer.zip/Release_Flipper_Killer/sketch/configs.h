#line 1 "C:\\Users\\soyko\\Documents\\esp32_marauder\\ESP32Marauder\\esp32_marauder\\configs.h"
#pragma once

#ifndef configs_h

  #define configs_h

  #define POLISH_POTATO

  //#define DEVELOPER

  // Developer-only escape hatch for unsigned or mismatched SD update images.
  // Production builds must remain fail-closed.
  //#define ALLOW_UNVERIFIED_SD_UPDATE

  //// BOARD TARGETS
  //#define MARAUDER_M5STICKC
  //#define MARAUDER_M5STICKCP2
  //#define MARAUDER_M5STACK_CORE2_AWS
  //#define MARAUDER_MINI
  //#define MARAUDER_V4
  //#define MARAUDER_V6
  //#define MARAUDER_V6_1
  //#define MARAUDER_V7
  //#define MARAUDER_V7_1
  //#define MARAUDER_KIT
  //#define GENERIC_ESP32
  //#define MARAUDER_FLIPPER
  //#define MARAUDER_MULTIBOARD_S3
  //#define ESP32_LDDB
  //#define MARAUDER_DEV_BOARD_PRO
  //#define XIAO_ESP32_S3
  //#define XIAO_ESP32_C5
  //#define MARAUDER_REV_FEATHER
  //#define MARAUDER_CYD_MICRO // 2432S028
  //#define MARAUDER_CYD_2USB // Another 2432S028 but it has tWo UsBs OoOoOoO
  //#define MARAUDER_CYD_GUITION // ESP32-2432S024 GUITION
  //#define MARAUDER_CYD_3_5_INCH
  //#define MARAUDER_C5
  //#define MARAUDER_T_DONGLE_C5
  //#define MARAUDER_CARDPUTER
  //#define MARAUDER_CARDPUTER_ADV
  //#define MARAUDER_V8
  //#define MARAUDER_PANCAKE
  //#define MARAUDER_MINI_V3
  //#define MARAUDER_M5_NANO_C6
  //#define DUAL_MINI_C5
  //#define MARAUDER_POOM
  #define MARAUDER_FLIPPER_KILLER
  //#define EXP_BOARD_S3
  #if defined(EXP_BOARD_S3) && !defined(MARAUDER_FLIPPER_KILLER)
    #define MARAUDER_FLIPPER_KILLER
  #endif
  // Waveshare ESP32-C5-Touch-LCD-3.5 board. Same silicon/panel class as the
  // Pancake V8 (ESP32-C5, ST7796 320x480, FT6336), so reuse Pancake's verified
  // C5 feature + geometry logic and override only this board's differing pins below.
  //#define MARAUDER_WS_C5_35
  #ifdef MARAUDER_WS_C5_35
    #define MARAUDER_PANCAKE
    #define MARAUDER_WS_C5_35_OVERRIDE
  #endif
  //// END BOARD TARGETS

  // The official Arduino board package supplies this identifier for the XIAO
  // ESP32-C5. Auto-select the matching Marauder profile so every translation
  // unit receives the same hardware contract, including the generated sketch.
  #if defined(ARDUINO_XIAO_ESP32C5) && !defined(XIAO_ESP32_C5)
    #define XIAO_ESP32_C5
  #endif

  // Allocated only while settings are loaded or updated. This accommodates
  // five saved WiFi profiles without permanently caching their passwords.
  #define JSON_SETTING_SIZE 6144

#define MARAUDER_VERSION "v1.19.2"

  #define GRAPH_REFRESH   100

  #define TRACK_EVICT_SEC 90 // Seconds before marking tracked MAC as tombstone

  #define DUAL_BAND_CHANNELS 51

  #define DISPLAY_BUFFER_LIMIT 20

  #define MODE_OFF 0
  #define MODE_RAINBOW 1
  #define MODE_ATTACK 2
  #define MODE_SNIFF 3
  #define MODE_CUSTOM 4

  //// HARDWARE NAMES
  #ifdef MARAUDER_M5STICKC
    #define HARDWARE_NAME "M5Stick-C Plus"
  #elif defined(MARAUDER_M5STICKCP2)
    #define HARDWARE_NAME "M5Stick-C Plus2"
  #elif defined(MARAUDER_M5STACK_CORE2_AWS)
    #define HARDWARE_NAME "M5Stack Core2 for AWS"
  #elif defined(MARAUDER_CARDPUTER)
    #define HARDWARE_NAME "M5 Cardputer"
  #elif defined(MARAUDER_CARDPUTER_ADV)
    #define HARDWARE_NAME "M5 Cardputer ADV"
  #elif defined(MARAUDER_MINI)
    #define HARDWARE_NAME "Marauder Mini"
  #elif defined(MARAUDER_V7)
    #define HARDWARE_NAME "Marauder v7"
  #elif defined(MARAUDER_V7_1)
    #define HARDWARE_NAME "Marauder v7.1"
  #elif defined(MARAUDER_REV_FEATHER)
    #define HARDWARE_NAME "Adafruit Feather ESP32-S2 Reverse TFT"
  #elif defined(MARAUDER_V4)
    #define HARDWARE_NAME "Marauder v4"
  #elif defined(MARAUDER_V6)
    #define HARDWARE_NAME "Marauder v6"
  #elif defined(MARAUDER_V6_1)
    #define HARDWARE_NAME "Marauder v6.1"
  #elif defined(MARAUDER_CYD_MICRO)
    #define HARDWARE_NAME "CYD 2432S028"
  #elif defined(MARAUDER_CYD_2USB)
    #define HARDWARE_NAME "CYD 2432S028 2USB"
  #elif defined(MARAUDER_CYD_3_5_INCH)
    #define HARDWARE_NAME "CYD 3.5inch"
  #elif defined(MARAUDER_CYD_GUITION)
    #define HARDWARE_NAME "CYD 2432S024 GUITION"
  #elif defined(MARAUDER_KIT)
    #define HARDWARE_NAME "Marauder Kit"
  #elif defined(MARAUDER_FLIPPER)
    #define HARDWARE_NAME "Flipper Zero Dev Board"
  #elif defined(MARAUDER_MULTIBOARD_S3)
    #define HARDWARE_NAME "Flipper Zero Multi Board S3"
  #elif defined(MARAUDER_FLIPPER_KILLER)
    #define HARDWARE_NAME "Flipper Killer S3"
  #elif defined(ESP32_LDDB)
    #define HARDWARE_NAME "ESP32 LDDB"
  #elif defined(MARAUDER_DEV_BOARD_PRO)
    #define HARDWARE_NAME "Flipper Zero Dev Board Pro"
  #elif defined(XIAO_ESP32_S3)
    #define HARDWARE_NAME "XIAO ESP32 S3"
  #elif defined(XIAO_ESP32_C5)
    #define HARDWARE_NAME "Seeed Studio XIAO ESP32-C5"
  #elif defined(MARAUDER_C5)
    #define HARDWARE_NAME "ESP32-C5 DevKit"
  #elif defined(MARAUDER_T_DONGLE_C5)
    #define HARDWARE_NAME "LilyGo T-Dongle C5"
  #elif defined(MARAUDER_V8)
    #define HARDWARE_NAME "Marauder v8"
  #elif defined(MARAUDER_PANCAKE)
    #define HARDWARE_NAME "Pancake Marauder V8"
  #elif defined(MARAUDER_MINI_V3)
    #define HARDWARE_NAME "Marauder Mini v3"
  #elif defined(DUAL_MINI_C5)
    #define HARDWARE_NAME "Dual Mini C5"
  #elif defined(MARAUDER_M5_NANO_C6)
    #define HARDWARE_NAME "M5 Nano C6"
  #elif defined(MARAUDER_POOM)
    #define HARDWARE_NAME "POOM"
  #else
    #define HARDWARE_NAME "ESP32"
  #endif

  //// END HARDWARE NAMES

 //// BOARD FEATURES
 #if defined(DUAL_MINI_C5)
    #define MARAUDER_MINI_V3
 #endif

  // CSI is provided by every ESP32-family target in the supported build
  // matrix. Chip-specific configuration and sample decoding live in
  // CsiMotionMonitor; do not infer the sample format from this capability.
  #if defined(MARAUDER_M5STICKC) || defined(MARAUDER_M5STICKCP2) || \
      defined(MARAUDER_M5STACK_CORE2_AWS) || \
      defined(MARAUDER_MINI) || defined(MARAUDER_V4) || defined(MARAUDER_V6) || \
      defined(MARAUDER_V6_1) || defined(MARAUDER_V7) || defined(MARAUDER_V7_1) || \
      defined(MARAUDER_KIT) || defined(GENERIC_ESP32) || defined(MARAUDER_FLIPPER) || \
      defined(MARAUDER_MULTIBOARD_S3) || defined(MARAUDER_FLIPPER_KILLER) || \
      defined(ESP32_LDDB) || \
      defined(MARAUDER_DEV_BOARD_PRO) || defined(XIAO_ESP32_S3) || \
      defined(XIAO_ESP32_C5) || defined(MARAUDER_REV_FEATHER) || \
      defined(MARAUDER_CYD_MICRO) || defined(MARAUDER_CYD_2USB) || \
      defined(MARAUDER_CYD_GUITION) || defined(MARAUDER_CYD_3_5_INCH) || \
      defined(MARAUDER_C5) || defined(MARAUDER_T_DONGLE_C5) || \
      defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV) || \
      defined(MARAUDER_V8) || defined(MARAUDER_PANCAKE) || \
      defined(MARAUDER_MINI_V3) || defined(MARAUDER_M5_NANO_C6) || \
      defined(MARAUDER_POOM)
    #define HAS_CSI_MOTION
  #endif

  #if defined(MARAUDER_MINI_V3) || defined(MARAUDER_V7) || \
      defined(MARAUDER_V7_1) || defined(MARAUDER_CARDPUTER) || \
      defined(MARAUDER_CARDPUTER_ADV) || defined(MARAUDER_M5STICKC) || \
      defined(MARAUDER_M5STICKCP2) || defined(MARAUDER_MINI) || \
      defined(MARAUDER_M5STACK_CORE2_AWS) || \
      defined(MARAUDER_REV_FEATHER)
    #define HAS_CSI_BUTTON_CONTROLS
  #endif

  #if defined(MARAUDER_M5STICKC) || defined(MARAUDER_M5STICKCP2)
    //#define FLIPPER_ZERO_HAT
    #define HAS_BATTERY
      #if defined(MARAUDER_M5STICKC)
        #define HAS_AXP192
      #else
        #define HAS_TP4057
      #endif
    #define HAS_BT
    #define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    #define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_MINI_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_DIRECT_UPLOAD
  #endif

  #if defined(MARAUDER_M5STACK_CORE2_AWS)
    #define HAS_BT
    #define HAS_BUTTONS
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_BATTERY
    #define HAS_PSRAM
    #define HAS_FACES_KEYBOARD
    #define HAS_DIRECT_UPLOAD
    #define HAS_CSI_BUTTON_CONTROLS
    #define HAS_IDF_3
    #define HAS_NIMBLE_2
    #define HAS_AXP192
    #define HAS_TOUCH
    #define HAS_CAP_TOUCH
    #define HAS_CORE2_BUTTONS
  #endif

  #if defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV)
    //#define FLIPPER_ZERO_HAT
    #define HAS_MINI_KB
    #define HAS_BT
    #define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    //#define HAS_BATTERY
    #define HAS_SCREEN
    #define HAS_MINI_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_DIRECT_UPLOAD

    #ifdef MARAUDER_CARDPUTER_ADV
      #define HAS_BATTERY
      #define BATTERY_ADC_PIN 10
      #define HAS_NEOPIXEL_LED
    #endif
  #endif

  #ifdef MARAUDER_MINI
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_MINI_KB
    #define HAS_BT
    #define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_MINI_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    //#define HAS_C5_SD
    #define HAS_SIMPLEX_DISPLAY
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_V7
    //#define FLIPPER_ZERO_HAT
    #define HAS_MINI_KB
    #define HAS_BATTERY
    #define HAS_BT
    #define HAS_BT_REMOTE
    #define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_C5_SD
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_V7_1
    //#define FLIPPER_ZERO_HAT
    #define HAS_MINI_KB
    #define HAS_BATTERY
    #define HAS_BT
    #define HAS_BT_REMOTE
    #define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_PSRAM
    //#define HAS_NIMBLE_2
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_REV_FEATHER
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    //#define HAS_BT
    #define HAS_MINI_KB
    #define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_MINI_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_V4
    #define HAS_TOUCH
    //#define FLIPPER_ZERO_HAT
    #define HAS_BATTERY
      #define HAS_IP5306
    #define HAS_BT
    //#define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_C5_SD
    #define HAS_DIRECT_UPLOAD
  #endif

  #if defined(MARAUDER_V6) || defined(MARAUDER_V6_1)
    #define HAS_TOUCH
    //#define FLIPPER_ZERO_HAT
    #define HAS_BATTERY
      #define HAS_IP5306
    #define HAS_BT
    #define HAS_BT_REMOTE
    #define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_C5_SD
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_CYD_MICRO
    #define HAS_TOUCH
    #define HAS_FLIPPER_LED
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    #define HAS_BT_REMOTE
    #define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_CYD_TOUCH
    //#define HAS_NIMBLE_2
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_CYD_2USB
    #define HAS_TOUCH
    #define HAS_FLIPPER_LED
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    #define HAS_BT_REMOTE
    #define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_CYD_TOUCH
    #define HAS_CYD_PORTRAIT
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_CYD_3_5_INCH
    #define HAS_TOUCH
    #define HAS_FLIPPER_LED
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    #define HAS_BT_REMOTE
    #define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    //#define HAS_CYD_TOUCH
    #define HAS_SEPARATE_SD
    #define HAS_CYD_PORTRAIT
    //#define HAS_NIMBLE_2
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_CYD_GUITION
    #define HAS_TOUCH
    #define HAS_FLIPPER_LED
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    #define HAS_BT_REMOTE
    #define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    //#define HAS_CYD_TOUCH
    //#define HAS_NIMBLE_2
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_KIT
    #define HAS_TOUCH
    //#define FLIPPER_ZERO_HAT
    #define HAS_BATTERY
    #define HAS_BT
    //#define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_C5_SD
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef GENERIC_ESP32
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    //#define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    //#define HAS_SCREEN
    //#define HAS_SD
    //#define HAS_TEMP_SENSOR
    //#define HAS_GPS
    //#define HAS_NIMBLE_2
  #endif

  #ifdef MARAUDER_FLIPPER
    #define HAS_FLIPPER_LED
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    //#define HAS_BT
    //#define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    //#define HAS_SCREEN
    #define HAS_GPS
    #define HAS_SD
    #define USE_SD
    #define HAS_PSRAM
    //#define HAS_TEMP_SENSOR
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_MULTIBOARD_S3
    #define HAS_FLIPPER_LED
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    //#define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    //#define HAS_SCREEN
    #define HAS_GPS
    #define HAS_SD
    #define USE_SD
    //#define HAS_PSRAM
    //#define HAS_TEMP_SENSOR
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_FLIPPER_KILLER
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    //#define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    //#define HAS_SCREEN
    //#define HAS_GPS
    #define HAS_SD
    #define USE_SD
    #define HAS_SEPARATE_SD
    #define HAS_ACT_LED
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    //#define HAS_PSRAM
    //#define HAS_TEMP_SENSOR
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef ESP32_LDDB
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    //#define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    //#define HAS_SCREEN
    #define HAS_SD
    #define USE_SD
    //#define HAS_TEMP_SENSOR
    //#define HAS_GPS
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    //#define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_DEV_BOARD_PRO
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    //#define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    //#define HAS_SCREEN
    #define HAS_SD
    #define USE_SD
    //#define HAS_TEMP_SENSOR
    #define HAS_GPS
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef XIAO_ESP32_S3
    #define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    //#define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    //#define HAS_SCREEN
    //#define HAS_SD
    //#define HAS_TEMP_SENSOR
    //#define HAS_GPS
  #endif

  #ifdef XIAO_ESP32_C5
    // Headless native-USB target. GPIO13/GPIO14 are reserved for USB D-/D+.
    #define HAS_BT
    #define HAS_GPS
    #define HAS_DUAL_BAND
    #define HAS_PSRAM
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define XIAO_LED_PIN 27
  #endif

  #ifdef MARAUDER_C5
    //#define HAS_FLIPPER_LED
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    //#define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    //#define HAS_SCREEN
    #define HAS_GPS
    #define HAS_C5_SD
    #define HAS_SD
    #define USE_SD
    #define HAS_DUAL_BAND
    //#define HAS_PSRAM
    //#define HAS_TEMP_SENSOR
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_T_DONGLE_C5
    #define HAS_BT
    #define HAS_T_DONGLE_DISPLAY
    #define HAS_T_DONGLE_LED
    #define T_DONGLE_LED_DATA_PIN 2
    #define T_DONGLE_LED_CLOCK_PIN 6
    #define T_DONGLE_TFT_CS_PIN 10
    #define T_DONGLE_SPI_SCLK_PIN 6
    #define T_DONGLE_SPI_MISO_PIN 7
    #define T_DONGLE_SPI_MOSI_PIN 2
    #define HAS_GPS
    #define HAS_C5_SD
    #define HAS_SD
    #define USE_SD
    #define HAS_DUAL_BAND
    #define HAS_PSRAM
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_V8
    #define HAS_TOUCH
    //#define HAS_FLIPPER_LED
    //#define FLIPPER_ZERO_HAT
    #define HAS_BATTERY
    #define HAS_BT
    //#define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_GPS
    #define HAS_C5_SD
    #define HAS_SD
    #define USE_SD
    #define HAS_DUAL_BAND
    #define HAS_PSRAM
    //#define HAS_TEMP_SENSOR
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_ACT_LED
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_PANCAKE
    #define HAS_TOUCH
    #define HAS_CAP_TOUCH
    //#define HAS_FLIPPER_LED
    //#define FLIPPER_ZERO_HAT
    #define HAS_BATTERY
    #define HAS_BT
    #define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_SCREEN
    #define HAS_FULL_SCREEN
    #define HAS_GPS
    #define HAS_C5_SD
    #define HAS_SD
    #define USE_SD
    #define HAS_DUAL_BAND
    #define HAS_PSRAM
    //#define HAS_TEMP_SENSOR
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_MINI_V3
    //#define HAS_TOUCH
    //#define HAS_FLIPPER_LED
    //#define FLIPPER_ZERO_HAT
    //#define HAS_BATTERY
    #define HAS_BT
    #define HAS_BUTTONS
    //#define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    #define HAS_MINI_KB
    #define HAS_SCREEN
    #define HAS_MINI_SCREEN
    #define HAS_GPS
    #define HAS_C5_SD
    #define HAS_SD
    #define USE_SD
    #define HAS_DUAL_BAND
    #define HAS_PSRAM
    //#define HAS_TEMP_SENSOR
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    //#define HAS_SIMPLEX_DISPLAY
    #define HAS_DIRECT_UPLOAD
  #endif

  #ifdef MARAUDER_POOM
    #define HAS_BT
    #define HAS_BUTTONS
    #define HAS_MINI_KB
    #define HAS_NEOPIXEL_LED
    #define HAS_SCREEN
    #define HAS_MINI_SCREEN
    #define HAS_SD
    #define USE_SD
    #define HAS_C5_SD
    #define HAS_DUAL_BAND
    #define HAS_PSRAM
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    #define HAS_DIRECT_UPLOAD
  #endif

  #if defined(MARAUDER_M5_NANO_C6)
    //#define FLIPPER_ZERO_HAT
    //#define HAS_MINI_KB
    //#define HAS_BATTERY
    #define HAS_BT
    //#define HAS_BUTTONS
    #define HAS_NEOPIXEL_LED
    //#define HAS_PWR_MGMT
    //#define HAS_SCREEN
    //#define HAS_MINI_SCREEN
    //#define HAS_SD
    //#define USE_SD
    //#define HAS_TEMP_SENSOR
    //#define HAS_GPS
    #define HAS_NIMBLE_2
    #define HAS_IDF_3
    //#define HAS_DIRECT_UPLOAD
  #endif

  // The bare XIAO carrier has no SD hardware. Keep the capability absent even
  // when another build-time definition is present in a shared build setup.
  #ifdef XIAO_ESP32_C5
    #undef HAS_C5_SD
    #undef HAS_SD
    #undef USE_SD
  #endif

  // Conserve internal RAM on every supported target that has neither PSRAM
  // nor an ESP32-C5. C5 targets retain their full capacities even when a
  // particular board does not expose PSRAM.
  #if !defined(HAS_PSRAM) && \
      !defined(MARAUDER_C5) && !defined(MARAUDER_T_DONGLE_C5) && \
      !defined(XIAO_ESP32_C5) && !defined(DUAL_MINI_C5)
    #define MARAUDER_NO_PSRAM_MEMORY_PROFILE
  #endif
  //// END BOARD FEATURES

  //// POWER MANAGEMENT
  #ifdef HAS_PWR_MGMT
    #if defined(HAS_AXP192)
      #include "AXP192.h"
    #endif

    #ifdef MARAUDER_M5STICKCP2 
        // Prevent StickCP2 from turning off when disconnect USB cable
        #define POWER_HOLD_PIN 4
    #endif
  #endif
  //// END POWER MANAGEMENT

  //// BUTTON DEFINITIONS
  #ifdef HAS_BUTTONS

    #ifdef MARAUDER_REV_FEATHER
      #define L_BTN -1
      #define C_BTN 1
      #define U_BTN 0
      #define R_BTN -1
      #define D_BTN 2

      //#define HAS_L
      //#define HAS_R
      #define HAS_U
      #define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL false
      #define U_PULL true
      #define R_PULL true
      #define D_PULL false
    #endif

    #ifdef MARAUDER_MINI
      #define L_BTN 13
      #define C_BTN 34
      #define U_BTN 36
      #define R_BTN 39
      #define D_BTN 35

      #define HAS_L
      #define HAS_R
      #define HAS_U
      #define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_V7
      #define L_BTN 13
      #define C_BTN 34
      #define U_BTN 36
      #define R_BTN 39
      #define D_BTN 35

      #define HAS_L
      #define HAS_R
      #define HAS_U
      #define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_V7_1
      #define L_BTN 13
      #define C_BTN 34
      #define U_BTN 36
      #define R_BTN 39
      #define D_BTN 35

      #define HAS_L
      #define HAS_R
      #define HAS_U
      #define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #if defined(MARAUDER_M5STICKC) || defined(MARAUDER_M5STICKCP2)
      #define L_BTN -1
      #define C_BTN 37
      #if defined(MARAUDER_M5STICKCP2)
        #define U_BTN 35
      #else
        #define U_BTN -1
      #endif
      #define R_BTN -1
      #define D_BTN 39

      //#define HAS_L
      //#define HAS_R
      #if defined(MARAUDER_M5STICKCP2)
        #define HAS_U
      #endif
      #define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_M5STACK_CORE2_AWS
      // The Core2 exposes three capacitive zones below the visible LCD. They
      // are sampled by Display and intentionally have no GPIO assignment.
      #define L_BTN -1
      #define C_BTN -1
      #define U_BTN -1
      #define R_BTN -1
      #define D_BTN -1

      #define HAS_U
      #define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #if defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV)
      #define L_BTN -1
      #define C_BTN 0
      #define U_BTN -1
      #define R_BTN -1
      #define D_BTN -1

      //#define HAS_L
      //#define HAS_R
      //#define HAS_U
      //#define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_V6
      #define L_BTN -1
      #define C_BTN 0
      #define U_BTN -1
      #define R_BTN -1
      #define D_BTN -1

      //#define HAS_L
      //#define HAS_R
      //#define HAS_U
      //#define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_V6_1
      #define L_BTN -1
      #define C_BTN 0
      #define U_BTN -1
      #define R_BTN -1
      #define D_BTN -1

      //#define HAS_L
      //#define HAS_R
      //#define HAS_U
      //#define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif  

    #ifdef MARAUDER_PANCAKE
      #define L_BTN -1
      #define C_BTN 28
      #define U_BTN -1
      #define R_BTN -1
      #define D_BTN -1

      //#define HAS_L
      //#define HAS_R
      //#define HAS_U
      //#define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_CYD_MICRO
      #define L_BTN -1
      #define C_BTN 0
      #define U_BTN -1
      #define R_BTN -1
      #define D_BTN -1

      //#define HAS_L
      //#define HAS_R
      //#define HAS_U
      //#define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_CYD_2USB
      #define L_BTN -1
      #define C_BTN 0
      #define U_BTN -1
      #define R_BTN -1
      #define D_BTN -1

      //#define HAS_L
      //#define HAS_R
      //#define HAS_U
      //#define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_CYD_3_5_INCH
      #define L_BTN -1
      #define C_BTN 0
      #define U_BTN -1
      #define R_BTN -1
      #define D_BTN -1

      //#define HAS_L
      //#define HAS_R
      //#define HAS_U
      //#define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_CYD_GUITION
      #define L_BTN -1
      #define C_BTN 0
      #define U_BTN -1
      #define R_BTN -1
      #define D_BTN -1

      //#define HAS_L
      //#define HAS_R
      //#define HAS_U
      //#define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_MINI_V3
      #ifndef DUAL_MINI_C5
        #define L_BTN 0
        #define C_BTN 1
        #define U_BTN 8//4
        #define R_BTN 9//8
        #define D_BTN 4//9
      #else
        #define L_BTN 0
        #define C_BTN 1
        #define U_BTN 4
        #define R_BTN 8
        #define D_BTN 9
      #endif

      #define HAS_L
      #define HAS_R
      #define HAS_U
      #define HAS_D
      #define HAS_C

      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
    #endif

    #ifdef MARAUDER_POOM
      #define L_BTN 3
      #define C_BTN 28
      #define U_BTN 7
      #define R_BTN 23
      #define D_BTN 24
      #define B_BTN 9
      #define HAS_L
      #define HAS_R
      #define HAS_U
      #define HAS_D
      #define HAS_C
      #define HAS_B
      #define L_PULL true
      #define C_PULL true
      #define U_PULL true
      #define R_PULL true
      #define D_PULL true
      #define B_PULL true
    #endif

  #endif
  //// END BUTTON DEFINITIONS

  #ifdef MARAUDER_POOM
    #define SCREEN_BUFFER
    #define MENU_FONT NULL
    #define TFT_WIDTH 128
    #define TFT_HEIGHT 64
    #define SCREEN_ORIENTATION 0
    #define SCREEN_WIDTH TFT_WIDTH
    #define SCREEN_HEIGHT TFT_HEIGHT
    #define HEIGHT_1 TFT_WIDTH
    #define WIDTH_1 TFT_WIDTH
    #define GRAPH_VERT_LIM (TFT_HEIGHT / 2 - 1)
    #define EXT_BUTTON_WIDTH 8
    #define STATUS_BAR_WIDTH 8
    #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH / 6)
    #define CHAR_WIDTH 6
    #define CHAN_PER_PAGE 7
    #define STATUSBAR_COLOR TFT_BLACK
    #define TEXT_HEIGHT 8
    #define BOT_FIXED_AREA 0
    #define TOP_FIXED_AREA 8
    #define YMAX TFT_HEIGHT
    #define MAX_SCREEN_BUFFER 5
    #define BUTTON_SCREEN_LIMIT 5
    #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
    #define BANNER_TEXT_SIZE 1
  #endif

  //// DISPLAY DEFINITIONS
  #ifdef HAS_SCREEN

    #if defined(MARAUDER_M5STACK_CORE2_AWS)
      #define CHAN_PER_PAGE 14
      #define SCREEN_CHAR_WIDTH 53
      #define HAS_ILI9341
      #define BANNER_TEXT_SIZE 1
      #define SCREEN_BUFFER
      #define MAX_SCREEN_BUFFER 13

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif
      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 320
      #endif

      #define SCREEN_ORIENTATION 1
      #define SCREEN_WIDTH TFT_HEIGHT
      #define SCREEN_HEIGHT TFT_WIDTH
      #define GRAPH_VERT_LIM (SCREEN_HEIGHT / 2 - 1)
      #define EXT_BUTTON_WIDTH 0
      #define CHAR_WIDTH 6
      #define HEIGHT_1 SCREEN_HEIGHT
      #define WIDTH_1 SCREEN_WIDTH
      #define STANDARD_FONT_CHAR_LIMIT (SCREEN_WIDTH / 6)
      #define TEXT_HEIGHT 16
      #define BOT_FIXED_AREA 0
      #define TOP_FIXED_AREA 32
      #define YMAX SCREEN_HEIGHT
      #define minimum(a,b) (((a) < (b)) ? (a) : (b))
      #define MENU_FONT &FreeMono9pt7b
      #define BUTTON_SCREEN_LIMIT 8
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6
      #define STATUSBAR_COLOR 0x4A49

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W / 2)
      #define REDBUTTON_H FRAME_H
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W / 2)
      #define GREENBUTTON_H FRAME_H

      #define TFT_MISO 38
      #define TFT_MOSI 23
      #define TFT_SCLK 18
      #define TFT_CS 5
      #define TFT_DC 15
      #define TFT_RST -1
      #define TFT_BL -1
      #define TOUCH_CS -1
      #define CTP_RST -1
      #define CTP_SDA 21
      #define CTP_SCL 22
      #define CAP_TOUCH_PANEL_WIDTH 320
      #define CAP_TOUCH_PANEL_HEIGHT 280
    #endif

    #ifdef MARAUDER_M5STICKC
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      //#define TFT_MISO 19
      #define TFT_MOSI 15
      #define TFT_SCLK 13
      #define TFT_CS 5
      #define TFT_DC 23
      #define TFT_RST 18
      #define TFT_BL -1
      #define TOUCH_CS -1
      //#define SD_CS 1

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 9

      #define BANNER_TEXT_SIZE 1

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 135
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 240
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 0

      #define SCREEN_ORIENTATION 1

      #define CHAR_WIDTH 6
      #define SCREEN_WIDTH TFT_HEIGHT // Originally 240
      #define SCREEN_HEIGHT TFT_WIDTH // Originally 320
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_WIDTH
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT (TFT_HEIGHT/10) // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX TFT_HEIGHT // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 6
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH (TFT_HEIGHT/16)
      #define LVGL_TICK_PERIOD 6
    
      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49

    #endif

  #if defined(MARAUDER_M5STICKCP2)
      #define CHAN_PER_PAGE 7

      #define MARAUDER_M5STICKC // From now on, everything is the same, except for one check in esp32_marauder.ino amd stickc_led.cpp/h

      #define SCREEN_CHAR_WIDTH 40
      #define TFT_MOSI 15
      #define TFT_SCLK 13
      #define TFT_CS 5
      #define TFT_DC 14
      #define TFT_RST 12
      #define TFT_BL 27
      #define TOUCH_CS -1

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 9

      #define BANNER_TEXT_SIZE 1

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 135
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 240
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 0

      #define SCREEN_ORIENTATION 0

      #define CHAR_WIDTH 6
      #define SCREEN_WIDTH TFT_HEIGHT // Originally 240
      #define SCREEN_HEIGHT TFT_WIDTH // Originally 320
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_WIDTH
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT (TFT_HEIGHT/10) // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX TFT_HEIGHT // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 6
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH (TFT_HEIGHT/16)
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50

      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H

      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H

      #define STATUSBAR_COLOR 0x4A49

    #endif

    #if defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV)
      #define CHAN_PER_PAGE 14

      #define SCREEN_CHAR_WIDTH 40
      //#define TFT_MISO -1
      #define TFT_MOSI 35
      #define TFT_SCLK 36
      #define TFT_CS 37
      #define TFT_DC 34
      #define TFT_RST 33
      #define TFT_BL 38
      // #define TOUCH_CS -1

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 9

      #define BANNER_TEXT_SIZE 1

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 135
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 240
      #endif

      #define EXT_BUTTON_WIDTH 0

      #define SCREEN_ORIENTATION 1

      #define CHAR_WIDTH 6
      #define SCREEN_WIDTH TFT_HEIGHT // 240 in landscape
      #define SCREEN_HEIGHT TFT_WIDTH // 135 in landscape
      #define GRAPH_VERT_LIM SCREEN_HEIGHT/2 - 1
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_WIDTH
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT (TFT_HEIGHT/10) // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX TFT_HEIGHT // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 6
      #define BUTTON_ARRAY_LEN 100
      #define STATUS_BAR_WIDTH (SCREEN_HEIGHT/16)
      #define LVGL_TICK_PERIOD 6
    
      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49

    #endif

    #ifdef MARAUDER_V4
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define HAS_ILI9341
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 320
      #endif

      #define TFT_SHIELD

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 30

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 21

      #define SCREEN_ORIENTATION 0

      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT 16 // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX 320 // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 12
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6
    
      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif

    #if defined(MARAUDER_V6) || defined(MARAUDER_V6_1)
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define HAS_ILI9341
    
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 320
      #endif

      #ifndef MARAUDER_CYD_MICRO
        #define TFT_DIY      
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 30

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 21

      #define SCREEN_ORIENTATION 0
    
      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT 16 // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX 320 // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 12
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif

    #if defined(MARAUDER_V8)
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define HAS_ILI9341
    
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 320
      #endif

      //#ifndef MARAUDER_CYD_MICRO
        //#define TFT_DIY
        //#define TFT_SHIELD
      //#endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 30

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 21

      #define SCREEN_ORIENTATION 0
    
      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT 16 // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX 320 // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 12
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif 

    #if defined(MARAUDER_PANCAKE)
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define HAS_ILI9341
    
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 320
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 480
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 30

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 26

      #define SCREEN_ORIENTATION 0
    
      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6)
      #define TEXT_HEIGHT 16
      #define BOT_FIXED_AREA 0
      #define TOP_FIXED_AREA 48
      #define YMAX 480
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 18
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W TFT_WIDTH / 2
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif

    #if defined(MARAUDER_CYD_MICRO)
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define HAS_ILI9341
    
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 320
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 30

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 21

      #define SCREEN_ORIENTATION 0
    
      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT 16 // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX 320 // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 12
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif

    #if defined(MARAUDER_CYD_2USB)
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define HAS_ILI9341
      #define HAS_ST7789
    
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 320
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 30

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 21

      #define SCREEN_ORIENTATION 0
    
      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT 16 // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX 320 // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 12
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif

    #if defined(MARAUDER_CYD_3_5_INCH)
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define HAS_ILI9341
      #define HAS_ST7796
    
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 320
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 480
      #endif

      #define TFT_DIY

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 30

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 33

      #define SCREEN_ORIENTATION 0
    
      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT 16 // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX 480 // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 12
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W TFT_WIDTH / 2
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif

    #if defined(MARAUDER_CYD_GUITION)
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define HAS_ILI9341
    
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 320
      #endif

      #define TFT_DIY

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 30

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 21

      #define SCREEN_ORIENTATION 0
    
      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT 16 // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX 320 // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 12
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif

    #ifdef MARAUDER_V7
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      //#define HAS_ILI9341
    
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 320
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define TFT_DIY

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 22

      #define EXT_BUTTON_WIDTH 0

      #define SCREEN_ORIENTATION 0
    
      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT 16 // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX 320 // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 12
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif

    #ifdef MARAUDER_V7_1
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      //#define HAS_ILI9341
    
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 320
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define TFT_DIY

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 22

      #define EXT_BUTTON_WIDTH 0

      #define SCREEN_ORIENTATION 0
    
      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT 16 // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX 320 // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 12
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50
    
      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H
    
      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif

    #ifdef MARAUDER_KIT
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define HAS_ILI9341
    
      #define BANNER_TEXT_SIZE 2

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 320
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define TFT_DIY
      #define KIT

      #define EXT_BUTTON_WIDTH 30

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 21

      #define SCREEN_ORIENTATION 0
    
      #define CHAR_WIDTH 12
      #define SCREEN_WIDTH TFT_WIDTH
      #define SCREEN_HEIGHT TFT_HEIGHT
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_HEIGHT
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT 16 // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX 320 // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 12
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH 16
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50

      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H

      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    
      #define KIT_LED_BUILTIN 13
    #endif
  
    #ifdef MARAUDER_MINI
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define TFT_MISO 19
      #define TFT_MOSI 23
      #define TFT_SCLK 18
      #define TFT_CS 27
      #define TFT_DC 26
      #define TFT_RST 5
      #define TFT_BL 32
      #define TOUCH_CS 21
      #define SD_CS 4

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 9

      #define BANNER_TEXT_SIZE 1

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 128
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 128
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 0

      #define SCREEN_ORIENTATION 0

      #define CHAR_WIDTH 6
      #define SCREEN_WIDTH TFT_WIDTH // Originally 240
      #define SCREEN_HEIGHT TFT_HEIGHT // Originally 320
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_WIDTH
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT (TFT_HEIGHT/10) // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX TFT_HEIGHT // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 9
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH (TFT_HEIGHT/16)
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50

      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H

      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    #endif

    #ifdef MARAUDER_REV_FEATHER
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      //#define TFT_MISO 37
      //#define TFT_MOSI 35
      //#define TFT_SCLK 36
      #define TFT_CS 42
      #define TFT_DC 40
      #define TFT_RST 41
      #define TFT_BL 45
      //#define TOUCH_CS 21
      #define SD_CS 4

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 9

      #define BANNER_TEXT_SIZE 1

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 240
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 135
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 0

      #define SCREEN_ORIENTATION 1

      #define CHAR_WIDTH 6
      #define SCREEN_WIDTH TFT_WIDTH // Originally 240
      #define SCREEN_HEIGHT TFT_HEIGHT // Originally 320
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_WIDTH
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT (TFT_HEIGHT/10) // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX TFT_HEIGHT // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 5
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH (TFT_HEIGHT/16)
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50

      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H

      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    #endif

    #ifdef MARAUDER_MINI_V3
      #define CHAN_PER_PAGE 7

      #define SCREEN_CHAR_WIDTH 40
      #define TFT_MISO 19
      #define TFT_MOSI 23
      #define TFT_SCLK 18
      #define TFT_CS 27
      #define TFT_DC 26
      #define TFT_RST 5
      #define TFT_BL 32
      #define TOUCH_CS 21
      #define SD_CS 4

      #define SCREEN_BUFFER

      #define MAX_SCREEN_BUFFER 9

      #define BANNER_TEXT_SIZE 1

      #ifndef TFT_WIDTH
        #define TFT_WIDTH 128
      #endif

      #ifndef TFT_HEIGHT
        #define TFT_HEIGHT 128
      #endif

      #define GRAPH_VERT_LIM TFT_HEIGHT/2 - 1

      #define EXT_BUTTON_WIDTH 0

      #define SCREEN_ORIENTATION 0

      #define CHAR_WIDTH 6
      #define SCREEN_WIDTH TFT_WIDTH // Originally 240
      #define SCREEN_HEIGHT TFT_HEIGHT // Originally 320
      #define HEIGHT_1 TFT_WIDTH
      #define WIDTH_1 TFT_WIDTH
      #define STANDARD_FONT_CHAR_LIMIT (TFT_WIDTH/6) // number of characters on a single line with normal font
      #define TEXT_HEIGHT (TFT_HEIGHT/10) // Height of text to be printed and scrolled
      #define BOT_FIXED_AREA 0 // Number of lines in bottom fixed area (lines counted from bottom of screen)
      #define TOP_FIXED_AREA 48 // Number of lines in top fixed area (lines counted from top of screen)
      #define YMAX TFT_HEIGHT // Bottom of screen area
      #define minimum(a,b)     (((a) < (b)) ? (a) : (b))
      //#define MENU_FONT NULL
      #define MENU_FONT &FreeMono9pt7b // Winner
      //#define MENU_FONT &FreeMonoBold9pt7b
      //#define MENU_FONT &FreeSans9pt7b
      //#define MENU_FONT &FreeSansBold9pt7b
      #define BUTTON_SCREEN_LIMIT 10
      #define BUTTON_ARRAY_LEN BUTTON_SCREEN_LIMIT
      #define STATUS_BAR_WIDTH (TFT_HEIGHT/16)
      #define LVGL_TICK_PERIOD 6

      #define FRAME_X 100
      #define FRAME_Y 64
      #define FRAME_W 120
      #define FRAME_H 50

      // Red zone size
      #define REDBUTTON_X FRAME_X
      #define REDBUTTON_Y FRAME_Y
      #define REDBUTTON_W (FRAME_W/2)
      #define REDBUTTON_H FRAME_H

      // Green zone size
      #define GREENBUTTON_X (REDBUTTON_X + REDBUTTON_W)
      #define GREENBUTTON_Y FRAME_Y
      #define GREENBUTTON_W (FRAME_W/2)
      #define GREENBUTTON_H FRAME_H
    
      #define STATUSBAR_COLOR 0x4A49
    #endif

  #endif
  //// END DISPLAY DEFINITIONS

  //// MENU DEFINITIONS
  #if defined(MARAUDER_M5STACK_CORE2_AWS)
    #define BANNER_TIME 50
    #define COMMAND_PREFIX "!"
    #define KEY_X (SCREEN_WIDTH / 2)
    #define KEY_Y 44
    #define KEY_W SCREEN_WIDTH
    #define KEY_H 24
    #define KEY_SPACING_X 0
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 28
  #endif

  #ifdef MARAUDER_V4
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 120 // Centre of key
    #define KEY_Y 50
    #define KEY_W 240 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif

  #if defined(MARAUDER_V6) || defined(MARAUDER_V6_1)
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 120 // Centre of key
    #define KEY_Y 50
    #define KEY_W 240 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif

  // Status bar right-side icon x-positions (SCREEN_WIDTH-relative)
  // V8 (240px): SD=170 WiFi=154 Force=138 Touch=186 Bat=204
  // Pancake (320px): SD=250 WiFi=234 Force=218 Touch=266 Bat=284
  #define SB_MEM_X    (SCREEN_WIDTH / 2 - 20)    // D%/P% text: 120 on V8, 160 on Pancake
  #define SB_SD_X     (SCREEN_WIDTH - 70)
  #define SB_WIFI_X   (SCREEN_WIDTH - 86)
  #define SB_FORCE_X  (SCREEN_WIDTH - 102)
  #define SB_TOUCH_X  (SCREEN_WIDTH - 54)
  #define SB_BAT_X    (SCREEN_WIDTH - 36)

  // Packet monitor oscilloscope geometry
  // PKT_HALF  = landscape height midpoint (zero-line y)
  // PKT_AXIS_W = x-axis draw width
  // HEIGHT_1 = TFT_WIDTH (landscape height): V8=240 Pancake=320
  // WIDTH_1  = TFT_HEIGHT (landscape width):  V8=320 Pancake=480
  #define PKT_HALF    (HEIGHT_1 / 2)
  #define PKT_AXIS_W  (WIDTH_1 - 10)

  #if defined(MARAUDER_V8)
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 120 // Centre of key
    #define KEY_Y 50
    #define KEY_W 240 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif

  #if defined(MARAUDER_PANCAKE)
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 160 // Centre of key
    #define KEY_Y 59
    #define KEY_W 320 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif

  #if defined(MARAUDER_CYD_MICRO)
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 120 // Centre of key
    #define KEY_Y 50
    #define KEY_W 240 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif

  #if defined(MARAUDER_CYD_2USB)
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 120 // Centre of key
    #define KEY_Y 50
    #define KEY_W 240 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif

  #if defined(MARAUDER_CYD_3_5_INCH)
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 160 // Centre of key
    #define KEY_Y 50
    #define KEY_W 320 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif

  #if defined(MARAUDER_CYD_GUITION)
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 120 // Centre of key
    #define KEY_Y 50
    #define KEY_W 240 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif

  #ifdef MARAUDER_V7
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 120 // Centre of key
    #define KEY_Y 50
    #define KEY_W 240 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif

  #ifdef MARAUDER_V7_1
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 120 // Centre of key
    #define KEY_Y 50
    #define KEY_W 240 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif

  #ifdef MARAUDER_KIT
    #define BANNER_TIME 100
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X 120 // Centre of key
    #define KEY_Y 50
    #define KEY_W 240 // Width and height
    #define KEY_H 22
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 22
    //#define BUTTON_ARRAY_LEN 5
  #endif
  
  #ifdef MARAUDER_MINI
    #define BANNER_TIME 50
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X (TFT_WIDTH/2) // Centre of key
    #define KEY_Y (TFT_HEIGHT/4.5)
    #define KEY_W TFT_WIDTH // Width and height
    #define KEY_H (TFT_HEIGHT/12.8)
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 10
  #endif

  #ifdef MARAUDER_REV_FEATHER
    #define BANNER_TIME 50
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X (TFT_WIDTH/2) // Centre of key
    #define KEY_Y (TFT_HEIGHT/4.5)
    #define KEY_W TFT_WIDTH // Width and height
    #define KEY_H (TFT_HEIGHT/12.8)
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 10
  #endif

  #ifdef MARAUDER_M5STICKC
    #define BANNER_TIME 50
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X (TFT_WIDTH/2) // Centre of key
    #define KEY_Y (TFT_HEIGHT/5)
    #define KEY_W TFT_HEIGHT // Width and height
    #define KEY_H (TFT_HEIGHT/17)
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 60
  #endif

  #if defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV)
    #define BANNER_TIME 50

    #define COMMAND_PREFIX "!"

    // Keypad start position, key sizes and spacing
    #define KEY_X (SCREEN_WIDTH/2) // Centre of key
    #define KEY_Y (TFT_HEIGHT/6)
    #define KEY_W SCREEN_WIDTH // Width and height
    #define KEY_H (TFT_HEIGHT/17)
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 7
  #endif

  #ifdef MARAUDER_MINI_V3
    #define BANNER_TIME 50
    
    #define COMMAND_PREFIX "!"
    
    // Keypad start position, key sizes and spacing
    #define KEY_X (TFT_WIDTH/2) // Centre of key
    #define KEY_Y (TFT_HEIGHT/4.5)
    #define KEY_W TFT_WIDTH // Width and height
    #define KEY_H (TFT_HEIGHT/12.8)
    #define KEY_SPACING_X 0 // X and Y gap
    #define KEY_SPACING_Y 1
    #define KEY_TEXTSIZE 1   // Font size multiplier
    #define ICON_W 22
    #define ICON_H 22
    #define BUTTON_PADDING 10
  #endif

  #ifdef MARAUDER_POOM
    #define BANNER_TIME 50
    #define COMMAND_PREFIX "!"
    #define KEY_X 64
    #define KEY_Y 13
    #define KEY_W 128
    #define KEY_H 10
    #define KEY_SPACING_X 0
    #define KEY_SPACING_Y 0
    #define KEY_TEXTSIZE 1
    #define ICON_W 8
    #define ICON_H 8
    #define BUTTON_PADDING 4
  #endif
  //// END MENU DEFINITIONS

  //// SD DEFINITIONS
  #if defined(USE_SD)

    #ifdef MARAUDER_V4
      #define SD_CS 12
    #endif

    #ifdef MARAUDER_V6
      #define SD_CS 12
    #endif

    #ifdef MARAUDER_V6_1
      #define SD_CS 14
    #endif

    #ifdef MARAUDER_CYD_MICRO
      #define SD_CS 5
    #endif

    #ifdef MARAUDER_CYD_2USB
      #define SD_CS 5
    #endif

    #ifdef MARAUDER_CYD_3_5_INCH
      #define SD_CS 5
    #endif

    #ifdef MARAUDER_CYD_GUITION
      #define SD_CS 5
    #endif

    #ifdef MARAUDER_KIT
      #define SD_CS 12
    #endif

    #ifdef MARAUDER_MINI
      #define SD_CS 4
    #endif

    #ifdef MARAUDER_V7
      #define SD_CS 4
    #endif

    #ifdef MARAUDER_V7_1
      #define SD_CS 4
    #endif

    #ifdef MARAUDER_REV_FEATHER
      #define SD_CS 5
    #endif

    #ifdef MARAUDER_M5STICKC
      #define SD_CS -1
    #endif

    #if defined(MARAUDER_M5STACK_CORE2_AWS)
      #define SD_CS 4
      #define SD_SCK 18
      #define SD_MISO 38
      #define SD_MOSI 23
      #define HAS_SEPARATE_SD
    #endif

    #if defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV)
      //#define SS      12
      #define SD_CS   12
      #define SD_SCK  40
      #define SD_MISO 39
      #define SD_MOSI 14
    #endif

    #ifdef MARAUDER_FLIPPER
      #define SD_CS 10
    #endif

    #ifdef MARAUDER_MULTIBOARD_S3
      #define SD_CS 10
    #endif

    #ifdef MARAUDER_FLIPPER_KILLER
      #define SD_CS   10
      #define SD_MOSI 11
      #define SD_SCK  12
      #define SD_MISO 13
    #endif

    #ifdef ESP32_LDDB
      #define SD_CS 4
    #endif

    #ifdef MARAUDER_DEV_BOARD_PRO
      #define SD_CS 4
    #endif

    #ifdef XIAO_ESP32_S3
      #define SD_CS 3
    #endif

    #if defined(MARAUDER_C5)
      #define SD_CS 10
    #elif defined(MARAUDER_T_DONGLE_C5)
      #define SD_CS 23
    #endif

    #ifdef MARAUDER_V8
      #define SD_CS 10
    #endif

    #ifdef MARAUDER_PANCAKE
      #define SD_CS 7
    #endif

    #ifdef MARAUDER_MINI_V3
      #define SD_CS 10
    #endif

    #ifdef MARAUDER_POOM
      #define SD_CS 5
    #endif

  #endif
  //// END SD DEFINITIONS

  //// SPACE SAVING COLORS
  #define TFTWHITE     1
  #define TFTCYAN      2
  #define TFTBLUE      3
  #define TFTRED       4
  #define TFTGREEN     5
  #define TFTGREY      6
  #define TFTGRAY      7
  #define TFTMAGENTA   8
  #define TFTVIOLET    9
  #define TFTORANGE    10
  #define TFTYELLOW    11
  #define TFTLIGHTGREY 12
  #define TFTPURPLE    13
  #define TFTNAVY      14
  #define TFTSILVER    15
  #define TFTDARKGREY  16
  #define TFTSKYBLUE   17
  #define TFTLIME      18
  //// END SPACE SAVING COLORS

  #define TFT_FARTGRAY 0x528a

  //// SCREEN STUFF
  #ifndef HAS_SCREEN

    #define BANNER_TIME GRAPH_REFRESH

    #define TFT_WIDTH 0
    #define TFT_HEIGHT 0

    #define TFT_BLACK 0
    #define TFT_WHITE 0
    #define TFT_CYAN 0
    #define TFT_BLUE 0
    #define TFT_RED 0
    #define TFT_GREEN 0
    #define TFT_GREY 0
    #define TFT_GRAY 0
    #define TFT_MAGENTA 0
    #define TFT_VIOLET 0
    #define TFT_ORANGE 0
    #define TFT_YELLOW 0
    #define STANDARD_FONT_CHAR_LIMIT 40
    #define FLASH_BUTTON -1

    #define CHAN_PER_PAGE 7

    #include <FS.h>
    #include <functional>
    #include <LinkedList.h>
    #include "SPIFFS.h"
    #include "Assets.h"

  #endif
  //// END SCREEN STUFF

  //// MEMORY LOWER LIMIT STUFF
  // These values are in bytes
  #ifdef MARAUDER_M5STICKC
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_M5STACK_CORE2_AWS)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_MINI)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_V7)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_V7_1)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_REV_FEATHER)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_V4)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_V6) || defined(MARAUDER_V6_1)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_CYD_MICRO)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_CYD_2USB)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_CYD_3_5_INCH)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_CYD_GUITION)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_KIT)
    #define MEM_LOWER_LIM 10000
  #elif defined(GENERIC_ESP32)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_FLIPPER)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_MULTIBOARD_S3)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_FLIPPER_KILLER)
    #define MEM_LOWER_LIM 10000
  #elif defined(ESP32_LDDB)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_DEV_BOARD_PRO)
    #define MEM_LOWER_LIM 10000
  #elif defined(XIAO_ESP32_S3)
    #define MEM_LOWER_LIM 10000
  #elif defined(XIAO_ESP32_C5)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_C5)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_T_DONGLE_C5)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_V8)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_PANCAKE)
    #define MEM_LOWER_LIM 10000
  #elif defined(MARAUDER_MINI_V3)
    #define MEM_LOWER_LIM 10000
  #else
    #define MEM_LOWER_LIM 10000
  #endif
  //// END MEMORY LOWER LIMIT STUFF

  //// NEOPIXEL STUFF  
  #ifdef HAS_NEOPIXEL_LED
    
    #if defined(ESP32_LDDB)
      #define PIN 17
    #elif defined(MARAUDER_DEV_BOARD_PRO)
      #define PIN 16
    #elif defined(MARAUDER_REV_FEATHER)
      #define PIN 33
    #elif defined(MARAUDER_CYD_MICRO)
      #define PIN 4
    #elif defined(MARAUDER_CYD_2USB)
      #define PIN 4
    #elif defined(MARAUDER_CYD_3_5_INCH)
      #define PIN 22
    #elif defined(MARAUDER_C5)
      #define PIN 27
    #elif defined(MARAUDER_V8)
      #define PIN 27
    #elif defined(MARAUDER_POOM)
      #define PIN 27
    #elif defined(MARAUDER_PANCAKE)
      #define PIN 27
    #elif defined(MARAUDER_CARDPUTER_ADV)
      #define PIN 21
    #elif defined(MARAUDER_M5_NANO_C6)
      #define PIN 20
    #else
      #define PIN 25
    #endif
  
  #endif
  //// END NEOPIXEL STUFF

  //// EVIL PORTAL STUFF

  #ifdef HAS_PSRAM
    #define MAX_HTML_SIZE 30000
  #else
    #define MAX_HTML_SIZE 11400
  #endif

  //// END EVIL PORTAL STUFF

  //// GPS STUFF
  #ifdef HAS_GPS
    #ifdef HAS_PSRAM
      #define mac_history_len 500
    #else
      #define mac_history_len 100
    #endif

    #define mac_history_len_half (mac_history_len / 2)

    #if defined(MARAUDER_V6) || defined(MARAUDER_V6_1)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 4
      #define GPS_RX 13
    #elif defined(MARAUDER_CYD_MICRO)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 22 // Whoever thought it would be a good idea to use UART0 for GPS...
      #define GPS_RX 27 // Now maybe we will be able to use CLI
    #elif defined(MARAUDER_CYD_2USB)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 22 // Whoever thought it would be a good idea to use UART0 for GPS...
      #define GPS_RX 27 // Now maybe we will be able to use CLI
    #elif defined(MARAUDER_CYD_3_5_INCH)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 21
      #define GPS_RX 25
    #elif defined(MARAUDER_CYD_GUITION)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 21 // Fits the extended I/O
      #define GPS_RX 22
    #elif defined(MARAUDER_V4)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 4
      #define GPS_RX 13
    #elif defined(MARAUDER_KIT)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 4
      #define GPS_RX 13
    #elif defined(MARAUDER_DEV_BOARD_PRO)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 21
      #define GPS_RX 17
    #elif defined(MARAUDER_MINI)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 21
      #define GPS_RX 22
    #elif defined(MARAUDER_V7)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 21
      #define GPS_RX 22
    #elif defined(MARAUDER_V7_1)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 21
      #define GPS_RX 22
    #elif defined(MARAUDER_FLIPPER)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 9
      #define GPS_RX 21
    #elif defined(MARAUDER_MULTIBOARD_S3)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 9
      #define GPS_RX 21
    #elif defined(MARAUDER_M5STICKC)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 33
      #define GPS_RX 32
    #elif defined(MARAUDER_M5STACK_CORE2_AWS)
      #define GPS_SERIAL_INDEX 2
      #define GPS_TX 13
      #define GPS_RX 14
    #elif defined(MARAUDER_CARDPUTER)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 1
      #define GPS_RX 2
    #elif defined(MARAUDER_CARDPUTER_ADV)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 15
      #define GPS_RX 13
    #elif defined(MARAUDER_REV_FEATHER)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 6
      #define GPS_RX 9
    #elif defined(MARAUDER_T_DONGLE_C5)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 12 // External GPS TX -> T-Dongle UART0 RX
      #define GPS_RX 11 // External GPS RX -> T-Dongle UART0 TX
    #elif defined(XIAO_ESP32_C5)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 12 // External GPS TX -> XIAO D7 / UART RX
      #define GPS_RX 11 // External GPS RX -> XIAO D6 / UART TX
    #elif defined(MARAUDER_C5)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 14
      #define GPS_RX 13
    #elif defined(MARAUDER_V8)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 14
      #define GPS_RX 13
    #elif defined(MARAUDER_PANCAKE)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 14
      #define GPS_RX 13
    #elif defined(MARAUDER_MINI_V3)
      #define GPS_SERIAL_INDEX 1
      #define GPS_TX 14
      #define GPS_RX 13
    #endif
  #else
    #define mac_history_len 100
    #define mac_history_len_half (mac_history_len / 2)
  #endif
  //// END GPS STUFF

  //// BATTERY STUFF
  #ifdef HAS_BATTERY

    #if defined(MARAUDER_M5STICKC) || defined(MARAUDER_M5STICKCP2) 
      #define I2C_SDA 33
      #define I2C_SCL 22

    #elif defined(MARAUDER_M5STACK_CORE2_AWS)
      #define I2C_SDA 21
      #define I2C_SCL 22

    #elif defined(MARAUDER_KIT)
      #define I2C_SDA 33
      #define I2C_SCL 22
      #define HAS_MAX1704X
      #undef HAS_AXP2101
      #undef HAS_IP5306

    // V4, V6 and V6.1 are also used by compatible third-party boards that may
    // have a MAX17048 expansion instead of an IP5306. Compile both probes and
    // select the gauge that responds at runtime.
    #elif defined(MARAUDER_V4) || defined(MARAUDER_V6) || defined(MARAUDER_V6_1)
      #define I2C_SDA 33
      #define I2C_SCL 22
      #define HAS_IP5306
      #define HAS_MAX1704X
      #undef HAS_AXP2101

    #elif defined(MARAUDER_MINI)
      #define I2C_SDA 33
      #define I2C_SCL 26

    #elif defined(MARAUDER_V7)
      #define I2C_SDA 33
      #define I2C_SCL 16
      #define HAS_MAX1704X
      #undef HAS_AXP2101
      #undef HAS_IP5306

    #elif defined(MARAUDER_V7_1)
      #define I2C_SDA 33
      #define I2C_SCL 27
      #define HAS_MAX1704X
      #undef HAS_AXP2101
      #undef HAS_IP5306

    #elif defined(MARAUDER_CYD_MICRO)
      #define I2C_SDA 22
      #define I2C_SCL 27

    #elif defined(MARAUDER_CYD_2USB)
      #define I2C_SDA 22
      #define I2C_SCL 27

    #elif defined(MARAUDER_CYD_3_5_INCH)
      #define I2C_SDA 32
      #define I2C_SCL 25

    #elif defined(MARAUDER_CYD_GUITION)
      #define I2C_SDA 22
      #define I2C_SCL 21

    #elif defined(MARAUDER_V8)
      #define I2C_SCL 4
      #define I2C_SDA 5

    #elif defined(MARAUDER_REV_FEATHER)
      #define I2C_SCL 4
      #define I2C_SDA 3
      #define HAS_MAX1704X
      #undef HAS_AXP2101
      #undef HAS_IP5306

    #elif defined(MARAUDER_PANCAKE)
      #define I2C_SDA 9
      #define I2C_SCL 10
      #define HAS_MAX1704X
      // FT6336 cap touch - shares I2C bus with MAX17048
      #define CTP_RST 8
      #define CTP_SDA I2C_SDA
      #define CTP_SCL I2C_SCL
    #endif


    //  If we know what we have, we can delete what we're not using
    #ifdef BATTERY_ADC_PIN
      #undef HAS_AXP2101
      #undef HAS_IP5306
      #undef HAS_MAX1704X
      #undef HAS_AXP192

    // No driver for this LiPo charger
    #elif defined(HAS_TP4057)
      #undef HAS_AXP2101
      #undef HAS_IP5306
      #undef HAS_MAX1704X
      #undef HAS_AXP192

    // These targets cover mixed hardware and intentionally retain both probes.
    #elif defined(MARAUDER_V4) || defined(MARAUDER_V6) || defined(MARAUDER_V6_1)
      #undef HAS_AXP2101
      #undef HAS_AXP192

    #elif defined(HAS_IP5306)
      #undef HAS_AXP2101
      #undef HAS_MAX1704X
      #undef HAS_AXP192

    #elif defined(HAS_AXP192)
      #undef HAS_AXP2101
      #undef HAS_IP5306
      #undef HAS_MAX1704X

    #elif defined(HAS_AXP2101)
      #undef HAS_IP5306
      #undef HAS_MAX1704X

    #elif defined(HAS_MAX1704X)
      #undef HAS_AXP2101
      #undef HAS_IP5306
      #undef HAS_AXP192


    #else       // punt
       // #define HAS_AXP2101
       #define HAS_IP5306
       #define HAS_MAX1704X
       #define HAS_AXP192
    #endif

  #endif  // HAS_BATTERY


  //// MARAUDER TITLE STUFF
  #ifdef MARAUDER_V4
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_V6) || defined(MARAUDER_V6_1)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_CYD_MICRO)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_CYD_2USB)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_CYD_3_5_INCH)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_CYD_GUITION)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_KIT)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_MINI)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_V7)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_V7_1)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_REV_FEATHER)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_C5)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(XIAO_ESP32_C5)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_V8)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_PANCAKE)
    #define MARAUDER_TITLE_BYTES 13578
  #elif defined(MARAUDER_MINI_V3)
    #define MARAUDER_TITLE_BYTES 13578
  #else
    #define MARAUDER_TITLE_BYTES 13578
  #endif
  //// END MARAUDER TITLE STUFF

  //// PCAP BUFFER STUFF
  
  #ifdef HAS_PSRAM
    #define BUF_SIZE 8 * 1024 // Had to reduce buffer size to save RAM. GG @spacehuhn
    #define SNAP_LEN 1 * 4096 // max len of each recieved packet
  //#elif !defined(HAS_ILI9341)
  //  #define BUF_SIZE 8 * 1024 // Had to reduce buffer size to save RAM. GG @spacehuhn
  //  #define SNAP_LEN 4096 // max len of each recieved packet
  #elif defined(MARAUDER_NO_PSRAM_MEMORY_PROFILE)
    #define BUF_SIZE 2 * 1024
    #define SNAP_LEN 1514
  #else
    #define BUF_SIZE 3 * 1024 // Had to reduce buffer size to save RAM. GG @spacehuhn
    #define SNAP_LEN 2324 // max len of each recieved packet
  #endif

  //// PCAP BUFFER STUFF

  //// STUPID CYD STUFF
  #if defined(HAS_CYD_TOUCH) || defined(HAS_C5_SD) || defined(HAS_SEPARATE_SD)
    #ifdef MARAUDER_CYD_MICRO
      #define XPT2046_IRQ  36
      #define XPT2046_MOSI 32
      #define XPT2046_MISO 39
      #define XPT2046_CLK  25
      #define XPT2046_CS   33

      #define SD_MISO      19
      #define SD_MOSI      23
      #define SD_SCK       18
    #endif

    #ifdef MARAUDER_CYD_2USB
      #define XPT2046_IRQ  36
      #define XPT2046_MOSI 32
      #define XPT2046_MISO 39
      #define XPT2046_CLK  25
      #define XPT2046_CS   33

      #define SD_MISO      19
      #define SD_MOSI      23
      #define SD_SCK       18
    #endif

    #ifdef MARAUDER_CYD_3_5_INCH
      #define SD_MISO      19
      #define SD_MOSI      23
      #define SD_SCK       18
    #endif

    #if defined(MARAUDER_C5)
      #define SD_MISO 2
      #define SD_MOSI 7
      #define SD_SCK  6
    #elif defined(MARAUDER_T_DONGLE_C5)
      #define SD_MISO 7
      #define SD_MOSI 2
      #define SD_SCK  6
    #endif

    #ifdef MARAUDER_V8
      #define SD_MISO TFT_MISO
      #define SD_MOSI TFT_MOSI
      #define SD_SCK  TFT_SCLK
    #endif

    #ifdef MARAUDER_PANCAKE
      #define SD_MISO TFT_MISO
      #define SD_MOSI TFT_MOSI
      #define SD_SCK  TFT_SCLK
    #endif

    #ifdef MARAUDER_V4
      #define SD_MISO TFT_MISO
      #define SD_MOSI TFT_MOSI
      #define SD_SCK  TFT_SCLK
    #endif

    #ifdef MARAUDER_V6
      #define SD_MISO TFT_MISO
      #define SD_MOSI TFT_MOSI
      #define SD_SCK  TFT_SCLK
    #endif

    #ifdef MARAUDER_V6_1
      #define SD_MISO TFT_MISO
      #define SD_MOSI TFT_MOSI
      #define SD_SCK  TFT_SCLK
    #endif

    #ifdef MARAUDER_KIT
      #define SD_MISO TFT_MISO
      #define SD_MOSI TFT_MOSI
      #define SD_SCK  TFT_SCLK
    #endif

    #ifdef MARAUDER_MINI
      #define SD_MISO TFT_MISO
      #define SD_MOSI TFT_MOSI
      #define SD_SCK  TFT_SCLK
    #endif

    #ifdef MARAUDER_V7
      #define SD_MISO TFT_MISO
      #define SD_MOSI TFT_MOSI
      #define SD_SCK  TFT_SCLK
    #endif

    #ifdef MARAUDER_MINI_V3
      #define SD_MISO TFT_MISO
      #define SD_MOSI TFT_MOSI
      #define SD_SCK  TFT_SCLK
    #endif

    #ifdef MARAUDER_POOM
      #define SD_MISO 8
      #define SD_MOSI 4
      #define SD_SCK  6
    #endif
  #endif
  //// END STUPID CYD STUFF

  //// FUNNY FLIPPER LED STUFF

  #ifdef HAS_FLIPPER_LED
    #ifdef MARAUDER_FLIPPER
      #define B_PIN 4
      #define G_PIN 5
      #define R_PIN 6
    #endif

    #ifdef MARAUDER_MULTIBOARD_S3
      #define B_PIN 4
      #define G_PIN 5
      #define R_PIN 6
    #endif

    #ifdef MARAUDER_CYD_MICRO
      #define B_PIN 17
      #define G_PIN 16
      #define R_PIN 4
    #endif

    #ifdef MARAUDER_CYD_2USB
      #define B_PIN 17
      #define G_PIN 16
      #define R_PIN 4
    #endif

    #ifdef MARAUDER_CYD_3_5_INCH
      #define B_PIN 17
      #define G_PIN 16
      #define R_PIN 22
    #endif

    #ifdef MARAUDER_CYD_GUITION
      #define B_PIN 17
      #define G_PIN 16
      #define R_PIN 4
    #endif
  #endif

  //// END FUNNY FLIPPER LED STUFF

  //// WIFI STUFF

  #ifndef HAS_DUAL_BAND
    #define HOP_DELAY 1000
  #else
    #define HOP_DELAY 250
  #endif

  //// ACT LED STUFF
  #ifdef HAS_ACT_LED

    #ifdef MARAUDER_V8
      #define ACT_LED_PIN 28
    #endif

    #ifdef MARAUDER_FLIPPER_KILLER
      #define ACT_LED_PIN 4
    #endif

  #endif


//// Waveshare C5 3.5" pin overrides (applied after Pancake defaults resolve)
#ifdef MARAUDER_WS_C5_35_OVERRIDE
  #undef HARDWARE_NAME
  #define HARDWARE_NAME "Marauder C5 3.5"
  // I2C bus is GPIO27/26 on this board (Pancake uses 9/10). CTP_SDA/SCL are
  // defined as I2C_SDA/I2C_SCL tokens upstream, so they follow automatically.
  #undef I2C_SDA
  #undef I2C_SCL
  #define I2C_SDA 27
  #define I2C_SCL 26
  // microSD chip-select is GPIO9 (Pancake uses 7); SD shares the LCD SPI bus,
  // whose pins come from User_Setup_ws_c5_35.h via SD_MISO/MOSI/SCK = TFT_*.
  #undef SD_CS
  #define SD_CS 9
  // No MAX17048 fuel gauge on this board; avoid probing a device that isn't here.
  #ifdef HAS_MAX1704X
    #undef HAS_MAX1704X
  #endif
  #ifdef HAS_BATTERY
    #undef HAS_BATTERY
  #endif
#endif

#endif
