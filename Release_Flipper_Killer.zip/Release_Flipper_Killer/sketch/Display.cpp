#line 1 "C:\\Users\\soyko\\Documents\\esp32_marauder\\ESP32Marauder\\esp32_marauder\\Display.cpp"
#include "Display.h"
#include "BootSplashBitmap.h"
#include "DisplayLine.h"
#include "lang_var.h"

#ifdef HAS_SCREEN

extern void backlightOn();

namespace {

uint8_t readLogoAlpha(uint16_t x, uint16_t y) {
  const uint32_t pixel_index = static_cast<uint32_t>(y) * JCMK_LOGO_WIDTH + x;
  const uint8_t packed = pgm_read_byte(JCMK_LOGO_BITMAP + pixel_index / 2);
  return pixel_index & 1 ? packed & 0x0F : packed >> 4;
}

uint8_t sampleLogoAlpha(uint32_t source_x, uint32_t source_y) {
  const uint16_t x0 = source_x >> 8;
  const uint16_t y0 = source_y >> 8;
  const uint16_t x1 = x0 + 1 < JCMK_LOGO_WIDTH ? x0 + 1 : x0;
  const uint16_t y1 = y0 + 1 < JCMK_LOGO_HEIGHT ? y0 + 1 : y0;
  const uint8_t x_fraction = source_x & 0xFF;
  const uint8_t y_fraction = source_y & 0xFF;

  const uint16_t top = readLogoAlpha(x0, y0) * (256 - x_fraction) +
                       readLogoAlpha(x1, y0) * x_fraction;
  const uint16_t bottom = readLogoAlpha(x0, y1) * (256 - x_fraction) +
                          readLogoAlpha(x1, y1) * x_fraction;
  return ((top * (256 - y_fraction) + bottom * y_fraction) + 32768) >> 16;
}

bool cleanLogoPixel(int16_t x, int16_t y, int16_t width, int16_t height,
                    uint32_t source_x_step, uint32_t source_y_step) {
  uint8_t white_neighbors = 0;
  for (int8_t y_offset = -1; y_offset <= 1; ++y_offset) {
    const int16_t sample_y = y + y_offset;
    if (sample_y < 0 || sample_y >= height) continue;
    for (int8_t x_offset = -1; x_offset <= 1; ++x_offset) {
      const int16_t sample_x = x + x_offset;
      if (sample_x < 0 || sample_x >= width) continue;
      if (sampleLogoAlpha(sample_x * source_x_step,
                          sample_y * source_y_step) >= 8) {
        ++white_neighbors;
      }
    }
  }
  return white_neighbors >= 5;
}

}  // namespace

Display::Display()
#ifdef HAS_CYD_TOUCH
  : touchscreenSPI(VSPI),
    touchscreen(XPT2046_CS, XPT2046_IRQ)
#endif
{
}

int8_t Display::menuButton(uint16_t *x, uint16_t *y, bool pressed, bool check_hold) {
  #ifdef HAS_ILI9341
    for (uint8_t b = BUTTON_ARRAY_LEN; b < BUTTON_ARRAY_LEN + 3; b++) {
      if (pressed && this->key[b].contains(*x, *y)) {
        this->key[b].press(true);  // tell the button it is pressed
      } else {
        this->key[b].press(false);  // tell the button it is NOT pressed
      }
    }

    for (uint8_t b = BUTTON_ARRAY_LEN; b < BUTTON_ARRAY_LEN + 3; b++) {
      if (!check_hold) {
        if ((this->key[b].justReleased()) && (!pressed)) {
          return b - BUTTON_ARRAY_LEN;
        }
      }
      else {
        if ((this->key[b].isPressed())) {
          return b - BUTTON_ARRAY_LEN;
        }
      }
    }

  #endif

  return -1;
}

uint8_t Display::updateTouch(uint16_t *x, uint16_t *y, uint16_t threshold) {
  #ifdef HAS_ILI9341
    if (!this->headless_mode) {
      #ifdef HAS_CAP_TOUCH
        // FT6336 capacitive touch: rotation-aware + edge exclusion
        {
          uint16_t raw_x, raw_y;
          const int8_t touch_state = ft6336_read_raw(&raw_x, &raw_y);
          if (touch_state != 1) {
            #ifdef MARAUDER_M5STACK_CORE2_AWS
              // Only bridge I2C transport errors. A confirmed zero-touch
              // status is a real release and must not delay the next tap.
              if (touch_state < 0 && core2_front_button >= 0 &&
                  millis() - core2_front_button_seen < 250) {
                *x = TFT_WIDTH / 2;
                *y = TFT_HEIGHT / 3 * core2_front_button + (TFT_HEIGHT / 6);
                return 1;
              }
              core2_front_button = -1;
            #endif
            return 0;
          }

          #ifdef MARAUDER_M5STACK_CORE2_AWS
            // Core2 reports its LCD in landscape coordinates. The lower
            // 40-pixel touch-only strip implements the three front buttons.
            if (raw_y >= 240 && raw_y < 280) {
              if (core2_full_touch_input) return 0;
              uint8_t button = raw_x < 120 ? UP_BUTTON :
                               raw_x < 220 ? SELECT_BUTTON : DOWN_BUTTON;
              core2_front_button = button;
              core2_front_button_seen = millis();
              *x = TFT_WIDTH / 2;
              *y = TFT_HEIGHT / 3 * button + (TFT_HEIGHT / 6);
              return 1;
            }
            core2_front_button = -1;
            // Normal operation deliberately ignores the LCD surface. It is
            // enabled only while the fallback on-screen keyboard is active.
            if (!core2_full_touch_input) return 0;
            if (raw_x >= SCREEN_WIDTH || raw_y >= SCREEN_HEIGHT) return 0;
            *x = raw_x;
            *y = raw_y;
            return 1;
          #endif

          // Discard touches within PANCAKE_TOUCH_MARGIN pixels of any panel edge
          #define PANCAKE_PANEL_W TFT_WIDTH
          #define PANCAKE_PANEL_H TFT_HEIGHT
          #define PANCAKE_TOUCH_MARGIN 5
          if (raw_x < PANCAKE_TOUCH_MARGIN || raw_x >= (PANCAKE_PANEL_W - PANCAKE_TOUCH_MARGIN)) return 0;
          if (raw_y < PANCAKE_TOUCH_MARGIN || raw_y >= (PANCAKE_PANEL_H - PANCAKE_TOUCH_MARGIN)) return 0;

          // Transform panel-native portrait coords to screen coords per rotation
          uint8_t rot = this->tft.getRotation();
          switch (rot) {
            case 0: // Portrait
              *x = raw_x;
              *y = raw_y;
              break;
            case 1: // Landscape 90 CW
              *x = raw_y;
              *y = (PANCAKE_PANEL_W - 1) - raw_x;
              break;
            case 2: // Portrait 180
              *x = (PANCAKE_PANEL_W - 1) - raw_x;
              *y = (PANCAKE_PANEL_H - 1) - raw_y;
              break;
            case 3: // Landscape 270 CW
              *x = (PANCAKE_PANEL_H - 1) - raw_y;
              *y = raw_x;
              break;
            default:
              *x = raw_x;
              *y = raw_y;
              break;
          }
          return 1;
        }
      #elif !defined(HAS_CYD_TOUCH)
        return this->tft.getTouch(x, y, threshold);
      #else
        if (this->touchscreen.tirqTouched() && this->touchscreen.touched()) {
          TS_Point p = this->touchscreen.getPoint();

          //*x = map(p.x, 200, 3700, 1, TFT_WIDTH);
          //*y = map(p.y, 240, 3800, 1, TFT_HEIGHT);

          uint8_t rot = this->tft.getRotation();

          //#ifdef HAS_CYD_PORTRAIT
          //  rot = 0;
          //#endif

          switch (rot) {
            case 0: // Standard Protrait
              *x = map(p.x, 200, 3700, 1, TFT_WIDTH);
              *y = map(p.y, 240, 3800, 1, TFT_HEIGHT);
              break;
            case 1:
              *x = map(p.y, 143, 3715, 0, TFT_HEIGHT);     // Horizontal (Y axis in touch, X on screen)
              *y = map(p.x, 3786, 216, 0, TFT_WIDTH);    // Vertical (X axis in touch, Y on screen)
              break;
            case 2:
              *x = map(p.x, 3700, 200, 1, TFT_WIDTH);
              *y = map(p.y, 3800, 240, 1, TFT_HEIGHT);
              break;
            case 3:
              *x = map(p.y, 3800, 240, 1, TFT_WIDTH);
              *y = map(p.x, 200, 3700, 1, TFT_HEIGHT);
              break;
          }
          return 1;
        }
        else
          return 0;
      #endif
    } else {
      return !this->headless_mode;
    }
  #endif

  return 0;
}

bool Display::isTouchHeld(uint16_t threshold) {
  static unsigned long touchStartTime = 0;
  static bool touchHeld = false;
  uint16_t x, y;

  if (this->updateTouch(&x, &y, threshold)) {
    // Touch detected
    if (touchStartTime == 0) {
      touchStartTime = millis();  // First touch timestamp
    } else if (!touchHeld && millis() - touchStartTime >= 1000) {
      touchHeld = true;  // Held for at least 1000ms
      return true;
    }
  } else {
    // Touch released
    touchStartTime = 0;
    touchHeld = false;
  }

  return false;
}

void Display::init() {
  tft.init();
  backlightOn();
}

void Display::setCalData(bool landscape) {
  #if !defined(HAS_CYD_TOUCH) && !defined(HAS_CAP_TOUCH)
    if (!landscape) {
      #ifdef TFT_SHIELD
        uint16_t calData[5] = { 275, 3494, 361, 3528, 4 }; // tft.setRotation(0); // Portrait with TFT Shield
      #elif defined(MARAUDER_CYD_3_5_INCH)
        uint16_t calData[5] = { 239, 3560, 262, 3643, 4 };
      #elif defined(MARAUDER_V8)
        //uint16_t calData[5] = { 351, 3279, 214, 3394, 2 };
        uint16_t calData[5] = { 312, 3431, 191, 3456, 2 };
      #elif defined(TFT_DIY)
        uint16_t calData[5] = { 339, 3470, 237, 3438, 2 }; // tft.setRotation(0); // Portrait with DIY TFT
      #endif
      #ifdef HAS_ILI9341
        tft.setTouch(calData);
      #endif
    }
    else {
      #ifdef TFT_SHIELD
        uint16_t calData[5] = { 391, 3491, 266, 3505, 7 }; // Landscape TFT Shield
      #elif defined(MARAUDER_CYD_3_5_INCH)
        uint16_t calData[5] = { 272, 3648, 234, 3565, 7 };
      #elif defined(MARAUDER_V8)
        uint16_t calData[5] = { 213, 3396, 350, 3275, 1 };
      #else if defined(TFT_DIY)
        uint16_t calData[5] = { 213, 3469, 320, 3446, 1 }; // Landscape TFT DIY
      #endif
      #ifdef HAS_ILI9341
        tft.setTouch(calData);
      #endif
    }
  #endif
}

// Function to prepare the display and the menus
void Display::RunSetup() {
  run_setup = false;

  // Need to declare new
  display_buffer = new LinkedList<String>();

  #ifdef SCREEN_BUFFER
    screen_buffer = new LinkedList<String>();
  #endif

  #ifdef HAS_CYD_TOUCH
    this->touchscreenSPI.begin(XPT2046_CLK, XPT2046_MISO, XPT2046_MOSI, XPT2046_CS);
    this->touchscreen.begin(touchscreenSPI);
    this->touchscreen.setRotation(0);
  #endif

  #ifdef HAS_CAP_TOUCH
    ft6336_init();
  #endif
  
  tft.init();

  tft.setRotation(SCREEN_ORIENTATION);

  tft.setCursor(0, 0);

  #ifdef HAS_ILI9341

    #if !defined(HAS_CYD_TOUCH) && !defined(HAS_CAP_TOUCH)
      this->setCalData();
    #endif

  #endif

  clearScreen();

  #ifdef KIT
    pinMode(KIT_LED_BUILTIN, OUTPUT);
  #endif

  #ifdef MARAUDER_REV_FEATHER
    pinMode(7, OUTPUT);

    delay(10);

    digitalWrite(7, HIGH);
  #endif
}

void Display::drawBootSplash() {
  const int16_t width = tft.width();
  const int16_t height = tft.height();
  #ifdef MARAUDER_POOM
    tft.fillScreen(TFT_BLACK);
    tft.setTextWrap(false);
    tft.setTextSize(1);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawCentreString("ESP32 Marauder", width / 2, 10, 1);
    tft.drawCentreString(version_number, width / 2, 27, 1);
    tft.drawCentreString("POOM", width / 2, 44, 1);
    tft.display(true);
    return;
  #endif
  #if defined(MARAUDER_CYD_3_5_INCH) || defined(MARAUDER_PANCAKE)
    constexpr bool half_scale_logo = true;
  #else
    constexpr bool half_scale_logo = false;
  #endif
  const marauder::BootSplashLayout layout =
      marauder::bootSplashLayout(width, height, half_scale_logo);

  tft.fillScreen(TFT_BLACK);
  tft.setTextWrap(false);
  tft.setFreeFont(NULL);
  tft.setTextSize(layout.text_size);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawCentreString("ESP32 Marauder", width / 2, layout.title_y, 1);

  const uint32_t source_x_step = layout.logo_width > 1
      ? (static_cast<uint32_t>(JCMK_LOGO_WIDTH - 1) << 8) /
            (layout.logo_width - 1)
      : 0;
  const uint32_t source_y_step = layout.logo_height > 1
      ? (static_cast<uint32_t>(JCMK_LOGO_HEIGHT - 1) << 8) /
            (layout.logo_height - 1)
      : 0;
  for (int16_t y = 0; y < layout.logo_height; ++y) {
    int16_t run_start = -1;
    for (int16_t x = 0; x <= layout.logo_width; ++x) {
      const bool white = x < layout.logo_width &&
          cleanLogoPixel(x, y, layout.logo_width, layout.logo_height,
                         source_x_step, source_y_step);
      if (white && run_start < 0) run_start = x;
      if (!white && run_start >= 0) {
        tft.drawFastHLine(layout.logo_x + run_start, layout.logo_y + y,
                          x - run_start, TFT_WHITE);
        run_start = -1;
      }
    }
  }

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawCentreString(version_number, width / 2, layout.version_y, 1);
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.drawCentreString("Initializing...", width / 2, layout.status_y, 1);
  tft.setTextSize(1);
}

void Display::tftDrawGraphObjects(byte x_scale)
{
  //draw the graph objects
  tft.fillRect(11, 5, x_scale+1, PKT_HALF, TFT_BLACK); // positive start point
  tft.fillRect(11, PKT_HALF + 1, x_scale+1, PKT_HALF - 1, TFT_BLACK); // negative start point
  tft.drawFastVLine(10, 5, PKT_HALF * 2 - 10, TFT_WHITE); // y axis
  tft.drawFastHLine(10, HEIGHT_1 - 1, PKT_AXIS_W, TFT_WHITE); // x axis
  tft.setTextColor(TFT_YELLOW); tft.setTextSize(1); // set parameters for y axis labels
  tft.setCursor(3, 6); tft.print("+"); // '+' at top of y axis
  tft.setCursor(3, PKT_HALF * 2 - 12); tft.print("0"); // "0" near baseline
}

void Display::tftDrawEapolColorKey(bool filter)
{
  //Display color key
  tft.setTextSize(1); tft.setTextColor(TFT_WHITE);
  tft.fillRect(14, 0, 15, 8, TFT_CYAN); tft.setCursor(30, 0); tft.println(" - EAPOL"); 
  if (filter) {
    uint16_t y = tft.getCursorY();
    tft.setCursor(14, y);
    tft.println("Filter Active");
  }
}

void Display::tftDrawColorKey()
{
  //Display color key
  tft.setTextSize(1); tft.setTextColor(TFT_WHITE);
  tft.fillRect(14, 0, 15, 8, TFT_GREEN); tft.setCursor(30, 0); tft.print(" - Beacons"); 
  tft.fillRect(14, 8, 15, 8, TFT_RED); tft.setCursor(30, 8); tft.print(" - Deauths");
  tft.fillRect(14, 16, 15, 8, TFT_BLUE); tft.setCursor(30, 16); tft.print(" - Probes");
}

void Display::tftDrawXScaleButtons(byte x_scale) {
  tft.drawFastVLine(234, 0, 20, TFT_WHITE);
  tft.setCursor(208, 21); tft.setTextColor(TFT_WHITE); tft.setTextSize(1); tft.print("X Scale:"); tft.print(x_scale);

  key[X_MINUS_INDEX].initButton(&tft, // x - box
                        220,
                        10, // x, y, w, h, outline, fill, text
                        20,
                        20,
                        TFT_BLACK, // Outline
                        TFT_CYAN, // Fill
                        TFT_BLACK, // Text
                        "-",
                        2);
  key[X_PLUS_INDEX].initButton(&tft, // x + box
                        249,
                        10, // x, y, w, h, outline, fill, text
                        20,
                        20,
                        TFT_BLACK, // Outline
                        TFT_CYAN, // Fill
                        TFT_BLACK, // Text
                        "+",
                        2);

  key[X_PLUS_INDEX].setLabelDatum(1, 5, MC_DATUM);
  key[X_MINUS_INDEX].setLabelDatum(1, 5, MC_DATUM);

  key[X_PLUS_INDEX].drawButton();
  key[X_MINUS_INDEX].drawButton();
}

void Display::tftDrawYScaleButtons(byte y_scale)
{
  tft.drawFastVLine(290, 0, 20, TFT_WHITE);
  tft.setCursor(265, 21); tft.setTextColor(TFT_WHITE); tft.setTextSize(1); tft.print("Y Scale:"); tft.print(y_scale);

  key[Y_MINUS_INDEX].initButton(&tft, // y - box
                        276,
                        10, // x, y, w, h, outline, fill, text
                        20,
                        20,
                        TFT_BLACK, // Outline
                        TFT_MAGENTA, // Fill
                        TFT_BLACK, // Text
                        "-",
                        2);
  key[Y_PLUS_INDEX].initButton(&tft, // y + box
                        305,
                        10, // x, y, w, h, outline, fill, text
                        20,
                        20,
                        TFT_BLACK, // Outline
                        TFT_MAGENTA, // Fill
                        TFT_BLACK, // Text
                        "+",
                        2);

  key[Y_MINUS_INDEX].setLabelDatum(1, 5, MC_DATUM);
  key[Y_PLUS_INDEX].setLabelDatum(1, 5, MC_DATUM);

  key[Y_MINUS_INDEX].drawButton();
  key[Y_PLUS_INDEX].drawButton();
}

void Display::tftDrawChannelScaleButtons(int set_channel, bool lnd_an) {
  #ifdef MARAUDER_POOM
    return;
  #endif
  #ifdef MARAUDER_PANCAKE
    TOP_FIXED_AREA_2 = lnd_an ? 48 : 64;
  #endif
  if (lnd_an) {
    tft.drawFastVLine(178, 0, 20, TFT_WHITE);
    tft.setCursor(145, 21); tft.setTextColor(TFT_WHITE); tft.setTextSize(1); tft.print(text10); tft.print(set_channel);

    key[CHAN_MINUS_INDEX].initButton(&tft, // channel - box
                          164,
                          10, // x, y, w, h, outline, fill, text
                          EXT_BUTTON_WIDTH - (EXT_BUTTON_WIDTH * 0.33),
                          EXT_BUTTON_WIDTH - (EXT_BUTTON_WIDTH * 0.33),
                          TFT_BLACK, // Outline
                          TFT_BLUE, // Fill
                          TFT_BLACK, // Text
                          "-",
                          2);
    key[CHAN_PLUS_INDEX].initButton(&tft, // channel + box
                          193,
                          10, // x, y, w, h, outline, fill, text
                          EXT_BUTTON_WIDTH - (EXT_BUTTON_WIDTH * 0.33),
                          EXT_BUTTON_WIDTH - (EXT_BUTTON_WIDTH * 0.33),
                          TFT_BLACK, // Outline
                          TFT_BLUE, // Fill
                          TFT_BLACK, // Text
                          "+",
                          2);
  }

  else {
    key[CHAN_MINUS_INDEX].initButton(&tft, // channel - box
                          (EXT_BUTTON_WIDTH / 2) * 6,
                          (STATUS_BAR_WIDTH * 2) + (EXT_BUTTON_WIDTH / 2), // x, y, w, h, outline, fill, text
                          EXT_BUTTON_WIDTH,
                          EXT_BUTTON_WIDTH,
                          TFT_BLACK, // Outline
                          TFT_BLUE, // Fill
                          TFT_BLACK, // Text
                          "-",
                          1);
    key[CHAN_PLUS_INDEX].initButton(&tft, // channel + box
                          (EXT_BUTTON_WIDTH / 2) * 10,
                          (STATUS_BAR_WIDTH * 2) + (EXT_BUTTON_WIDTH / 2), // x, y, w, h, outline, fill, text
                          EXT_BUTTON_WIDTH,
                          EXT_BUTTON_WIDTH,
                          TFT_BLACK, // Outline
                          TFT_BLUE, // Fill
                          TFT_BLACK, // Text
                          "+",
                          1);
  }

  key[CHAN_MINUS_INDEX].setLabelDatum(1, 5, MC_DATUM);
  key[CHAN_PLUS_INDEX].setLabelDatum(1, 5, MC_DATUM);

  key[CHAN_MINUS_INDEX].drawButton();
  key[CHAN_PLUS_INDEX].drawButton();
}

void Display::tftDrawChanHopButton(bool lnd_an, bool en) {
  #ifdef MARAUDER_POOM
    return;
  #endif
  #ifdef MARAUDER_PANCAKE
    TOP_FIXED_AREA_2 = lnd_an ? 48 : 64;
  #endif
  if (lnd_an) {
    if (!en) {
      key[CHAN_HOP_INDEX].initButton(&tft, // Exit box
                        137,
                        10, // x, y, w, h, outline, fill, text
                        EXT_BUTTON_WIDTH,
                        EXT_BUTTON_WIDTH,
                        TFT_ORANGE, // Outline
                        TFT_RED, // Fill
                        TFT_BLACK, // Text
                        "X",
                        2);
    } else {
      key[CHAN_HOP_INDEX].initButton(&tft, // Exit box
                        137,
                        10, // x, y, w, h, outline, fill, text
                        EXT_BUTTON_WIDTH,
                        EXT_BUTTON_WIDTH,
                        TFT_WHITE, // Outline
                        TFT_GREEN, // Fill
                        TFT_BLACK, // Text
                        "O",
                        2);
    }
  }

  else {
    if (!en) {
      key[CHAN_HOP_INDEX].initButton(&tft, // Exit box
                        (EXT_BUTTON_WIDTH / 2) * 14,
                        (STATUS_BAR_WIDTH * 2) + (EXT_BUTTON_WIDTH / 2), // x, y, w, h, outline, fill, text
                        EXT_BUTTON_WIDTH,
                        EXT_BUTTON_WIDTH,
                        TFT_ORANGE, // Outline
                        TFT_RED, // Fill
                        TFT_BLACK, // Text
                        "HOP",
                        1);
    } else {
      key[CHAN_HOP_INDEX].initButton(&tft, // Exit box
                        (EXT_BUTTON_WIDTH / 2) * 14,
                        (STATUS_BAR_WIDTH * 2) + (EXT_BUTTON_WIDTH / 2), // x, y, w, h, outline, fill, text
                        EXT_BUTTON_WIDTH,
                        EXT_BUTTON_WIDTH,
                        TFT_WHITE, // Outline
                        TFT_GREEN, // Fill
                        TFT_BLACK, // Text
                        "HOP",
                        1);
    }
  }

  key[CHAN_HOP_INDEX].setLabelDatum(1, 5, MC_DATUM);

  key[CHAN_HOP_INDEX].drawButton();
}

void Display::tftDrawExitScaleButtons(bool lnd_an) {
  #ifdef MARAUDER_POOM
    return;
  #endif
  #ifdef MARAUDER_PANCAKE
    TOP_FIXED_AREA_2 = lnd_an ? 48 : 64;
  #endif
  //tft.drawFastVLine(178, 0, 20, TFT_WHITE);
  //tft.setCursor(145, 21); tft.setTextColor(TFT_WHITE); tft.setTextSize(1); tft.print("Channel:"); tft.print(set_channel);

  if (lnd_an) {

    key[EXIT_BUTTON_INDEX].initButton(&tft, // Exit box
                      137,
                      10, // x, y, w, h, outline, fill, text
                      EXT_BUTTON_WIDTH - (EXT_BUTTON_WIDTH * 0.33),
                      EXT_BUTTON_WIDTH - (EXT_BUTTON_WIDTH * 0.33),
                      TFT_ORANGE, // Outline
                      TFT_RED, // Fill
                      TFT_BLACK, // Text
                      "X",
                      2);
  }

  else {
    key[EXIT_BUTTON_INDEX].initButton(&tft, // Exit box
                      EXT_BUTTON_WIDTH,
                      (STATUS_BAR_WIDTH * 2) + (EXT_BUTTON_WIDTH / 2), // x, y, w, h, outline, fill, text
                      EXT_BUTTON_WIDTH,
                      EXT_BUTTON_WIDTH,
                      TFT_ORANGE, // Outline
                      TFT_RED, // Fill
                      TFT_BLACK, // Text
                      "X",
                      1);
  }

  key[EXIT_BUTTON_INDEX].setLabelDatum(1, 5, MC_DATUM);

  key[EXIT_BUTTON_INDEX].drawButton();
}

void Display::twoPartDisplay(String center_text)
{
  tft.setTextColor(TFT_BLACK, TFT_YELLOW);
  tft.fillRect(0,16,HEIGHT_1,144, TFT_YELLOW);
  //tft.drawCentreString(center_text,120,82,1);
  tft.setTextWrap(true);
  tft.setFreeFont(NULL);
  //showCenterText(center_text, 82);
  //tft.drawCentreString(center_text,120,82,1);
  tft.setCursor(0, 82);
  tft.println(center_text);
  tft.setFreeFont(MENU_FONT);
  tft.setTextWrap(false);
}

void Display::touchToExit()
{
  tft.setTextColor(TFT_BLACK, TFT_LIGHTGREY);
  tft.fillRect(0, 32, SCREEN_WIDTH, 16, TFT_LIGHTGREY);
  tft.drawCentreString(text11, SCREEN_WIDTH / 2, 32, 2);
}


// Function to just draw the screen black
void Display::clearScreen()
{
  #ifdef MARAUDER_PANCAKE
    TOP_FIXED_AREA_2 = 48;
  #endif
  //Serial.println(F("clearScreen()"));
  #ifndef MARAUDER_V7
    tft.fillScreen(TFT_BLACK);
    tft.setCursor(0, 0);
  #elif defined(MARAUDER_MINI) || defined(MARAUDER_MINI_V3)
    tft.fillRect(0, 0, TFT_WIDTH, TFT_HEIGHT, TFT_BLACK);
    tft.setCursor(0, 0);
  #else
    tft.fillRect(0, 0, TFT_WIDTH, TFT_HEIGHT, TFT_BLACK);
    tft.setCursor(0, 0);
  #endif
}

#ifdef SCREEN_BUFFER
void Display::scrollScreenBuffer(bool down) {
  // Scroll screen normal direction (Up)
  if (!down) {
    this->screen_buffer->shift();
  }
}
#endif

void Display::processAndPrintString(TFT_eSPI& tft, const String& originalString) {
  // Define colors
  uint16_t text_color = TFT_GREEN; // Default text color
  uint16_t background_color = TFT_BLACK; // Default background color

  String new_string = originalString;

  // Check for color macros at the start of the string
  if (new_string.startsWith(";")) {
    if (new_string.startsWith(RED_KEY)) {
      text_color = TFT_RED;
      new_string.remove(0, strlen(RED_KEY)); // Remove the macro
    } else if (new_string.startsWith(GREEN_KEY)) {
      text_color = TFT_GREEN;
      new_string.remove(0, strlen(GREEN_KEY)); // Remove the macro
    } else if (new_string.startsWith(CYAN_KEY)) {
      text_color = TFT_CYAN;
      new_string.remove(0, strlen(CYAN_KEY)); // Remove the macro
    } else if (new_string.startsWith(WHITE_KEY)) {
      text_color = TFT_WHITE;
      new_string.remove(0, strlen(WHITE_KEY)); // Remove the macro
    } else if (new_string.startsWith(MAGENTA_KEY)) {
      text_color = TFT_MAGENTA;
      new_string.remove(0, strlen(MAGENTA_KEY)); // Remove the macro
    }
  }

  // Scan output uses the built-in 6-pixel font. CHAR_WIDTH describes larger
  // menu/layout cells on full-size displays, so using it here cut their line
  // capacity in half and truncated values such as MAC addresses.
  char line[STANDARD_FONT_CHAR_LIMIT + 1];
  fitDisplayLine(line, sizeof(line), new_string.c_str()); // GCOVR_EXCL_LINE

  // Set text color and print the string
  tft.setTextColor(text_color, background_color);
  tft.print(line);
}

bool Display::queueLine(const String& line) {
  if (display_buffer == nullptr) return false;
  if (!display_queue_pressure.allow(display_buffer->size())) return false;
  if (!marauder::RuntimeMemoryGuard::instance().allow(line.length() + 48))
    return false;
  return display_buffer->add(line);
}

bool Display::queueCriticalLine(const String& line) {
  if (display_buffer == nullptr) return false;
  if (!display_queue_pressure.allow(display_buffer->size())) return false;
  return display_buffer->add(line);
}

void Display::displayBuffer(bool do_clear)
{
  if (this->display_buffer->size() > 0)
  {

    int print_count = 2;

    while ((display_buffer->size() > 0) && (print_count > 0))
    {
      // Freeze adding to display buffer
      if (display_buffer->size() > DISPLAY_BUFFER_LIMIT)
        this->printing = true;

      /*#ifndef SCREEN_BUFFER
        xPos = 0;
        if ((display_buffer->size() > 0) && (!loading))
        {
          //printing = true;
          delay(print_delay_1);
          yDraw = scroll_line(TFT_RED);
          tft.setCursor(xPos, yDraw);
          tft.setTextColor(TFT_GREEN, TFT_BLACK);
          tft.print(display_buffer->shift());
          //printing = false;
          delay(print_delay_2);
        }
        if (!tteBar)
          blank[(18+(yStart - TOP_FIXED_AREA) / TEXT_HEIGHT)%19] = xPos;
        else
          blank[(18+(yStart - TOP_FIXED_AREA_2) / TEXT_HEIGHT)%19] = xPos;
      #else*/
        xPos = 0;
        if (this->screen_buffer->size() >= MAX_SCREEN_BUFFER)
          this->scrollScreenBuffer();

        screen_buffer->add(display_buffer->shift());

        for (int i = 0; i < this->screen_buffer->size(); i++) {
		  #ifdef MARAUDER_POOM
			tft.setCursor(xPos, STATUS_BAR_WIDTH + (i * TEXT_HEIGHT));
		  #elif defined(MARAUDER_PANCAKE)
			tft.setCursor(xPos, (i * TEXT_HEIGHT) + TOP_FIXED_AREA_2);
		  #else
			#ifdef HAS_TOUCH
			  tft.setCursor(xPos, (i * 12) + ((TFT_HEIGHT / 6) * 1.3));
			#else
			  tft.setCursor(xPos, (i * 12) + (TFT_HEIGHT / 6));
			#endif
		  #endif

          this->processAndPrintString(tft, this->screen_buffer->get(i));
        }
      //#endif

      print_count--;
    }

    this->printing = false;
  }
}

void Display::showCenterText(const char* text, int y, bool small_pp, uint8_t text_size)
{
  if (!text)
    text = "";

  // Centering already assumes either the 1x bitmap font or text_size scaling.
  // Apply that size here as well so callers never inherit a previous UI's
  // text scale (for example, the 2x upload percentage display).
  const uint8_t effective_text_size = resolveDisplayTextSize(small_pp, text_size);
  tft.setTextSize(effective_text_size);

  size_t len = strlen(text);

  if (!small_pp)
    tft.setCursor((SCREEN_WIDTH - (len * (6 * effective_text_size))) / 2, y);
  else
    tft.setCursor((SCREEN_WIDTH - (len * 6)) / 2, y);

  tft.println(text);
}


void Display::updateBanner(String msg)
{
  this->buildBanner(msg, current_banner_pos);
}


void Display::buildBanner(String msg, int xpos)
{
  int h = TEXT_HEIGHT;

  #if defined(MARAUDER_CARDPUTER) || defined(MARAUDER_CARDPUTER_ADV)
    int banner_y = STATUS_BAR_WIDTH + 8;
  #else
    int banner_y = STATUS_BAR_WIDTH;
  #endif
  this->tft.fillRect(0, STATUS_BAR_WIDTH, SCREEN_WIDTH, TEXT_HEIGHT + (banner_y - STATUS_BAR_WIDTH), TFT_BLACK);
  this->tft.setFreeFont(NULL);           // Font 4 selected
  this->tft.setTextSize(BANNER_TEXT_SIZE);           // Font size scaling is x1
  this->tft.setTextColor(TFT_WHITE, TFT_BLACK);  // Black text, no background colour
  this->showCenterText(msg.c_str(), banner_y);
}

#endif
